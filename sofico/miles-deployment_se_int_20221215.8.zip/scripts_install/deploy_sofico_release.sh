#!/bin/bash

# exit script on any error
set -euo pipefail

RUN_DATABASE_UPGRADE=0
RUN_SERVER_UPGRADE=0
RUN_RIA_UPGRADE=0
RUN_BATCH_UPGRADE=0
RUN_WEB_UPGRADE=0

for arg in "$@"; do
    if [ "${arg}" == "-d" ]; then
        RUN_DATABASE_UPGRADE=1
    fi

    if [ "${arg}" == "-s" ]; then
        RUN_SERVER_UPGRADE=1
    fi

    if [ "${arg}" == "-r" ]; then
        RUN_RIA_UPGRADE=1
    fi

    if [ "${arg}" == "-b" ]; then
        RUN_BATCH_UPGRADE=1
    fi

    if [ "${arg}" == "-w" ]; then
        RUN_WEB_UPGRADE=1
    fi

    if [ "${arg}" == "-a" ]; then
        RUN_DATABASE_UPGRADE=1
        RUN_SERVER_UPGRADE=1
        RUN_RIA_UPGRADE=1
        RUN_BATCH_UPGRADE=1
    fi
done

if [ $# -eq 1 ]; then
    RUN_DATABASE_UPGRADE=1
    RUN_SERVER_UPGRADE=1
    RUN_RIA_UPGRADE=1
    RUN_BATCH_UPGRADE=1
fi

# create env xml file
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

#set variables
SOFICO_ZIP=$(basename "$1")
echo "File to process: ${SOFICO_ZIP}"

SOFICO_DIR=$(dirname "$1")
echo "Sofico Folder ${SOFICO_DIR}"

#while developing use this line else do this when done
rm -rf "${deploy_tmp_home}"/extracted_build
mkdir -p "${deploy_tmp_home}"/extracted_build

#unzip the sofico file
echo unzipping "$1"
unzip "$1" -d "${deploy_tmp_home}"/extracted_build/

#set the root path for deployment
echo build root path
PATH_ROOT="${deploy_tmp_home}"/extracted_build
echo root path is "${PATH_ROOT}"

#get the Build for this release
RELEASE=$(sed '1q;d' "${PATH_ROOT}"/manifest.txt | awk -F = '{print $2}')
echo "Release to process: ${RELEASE}"
DELIVERY=$(sed '2q;d' "${PATH_ROOT}"/manifest.txt | awk -F = '{print $2}')
echo "Delivery to process: ${DELIVERY}"
BUILD=$(sed '3q;d' "${PATH_ROOT}"/manifest.txt | awk -F = '{print $2}')
echo "Build to process: ${BUILD}"

# in case that we download a nightly patch from Sofico, but don't add "nightly" to the file name, here is another check
# check if manifest.txt/Delivery= contains 'nightly'. abort deployments of 'nightly' patches on PRD
if [[ "${DELIVERY,,}" == *"nightly"* ]] && [ "${environment}" == "prd" ]; then
    echo "ERROR: Nightly Sofico deployment files are not allowed on PRD"
    exit 1
fi

#find Sofico patch file, also taking care of emergency patches
#it will find the normal 2WK files or "<filename>-EP<number>.extension"
#even if multiple files are present, it will choose the latest file
find_patch_file() {
    source_path="$1"
    file_name="$2"
    echo "find '${file_name}' in '${source_path}'"
    find "${source_path}" -name "${file_name}"
    tmpvar=$(find "${source_path}" -name "${file_name}" | tail -1)
    echo "using: ${tmpvar}"
}

unzip_patch_file() {
    find_patch_file "$1" "$2"
    unzip "${tmpvar}" -d "$3"
}

copy_patch_file() {
    find_patch_file "$1" "$2"
    echo "copy ${tmpvar} to $1/$3"
    cp "${tmpvar}" "$1"/"$3"
}

# for the release-upgrade environment we have used the country codes/names "es2/Spain2", "it2/Italy2" etc.
# but since we want to still want to use the Spanish e.g. ProductConfig for "TST_ES2" we need to to remove the "2" from the variable
clean_country_variable() {
    # Just as the explanation above (es2=es) we have to treat prep=uk
    if [ "${1}" = "prep" ]; then
        echo "uk"
    elif [ "${1}" = "Prep" ]; then
        echo "UnitedKingdom"
    else
        echo $(echo "${1}" | sed 's/2$//')
    fi
}

clean_country_full=$(clean_country_variable "${country_full}")
clean_country=$(clean_country_variable "${country}")

######################################################################################
#Batch
if [ "${RUN_BATCH_UPGRADE}" -eq 1 ]; then
    echo "Running batch upgrade."
    PATH_BATCH="${PATH_ROOT}"/batch
    PATH_BATCH_WORKING="${PATH_BATCH}"/working
    mkdir "${PATH_BATCH_WORKING}"
    echo PATH_BATCH_WORKING
    unzip "${PATH_BATCH}"/MilesCLI_"${RELEASE}"_"${BUILD}"_jboss_linux.zip -d "${PATH_BATCH_WORKING}"
    chmod +x "${PATH_BATCH_WORKING}"/jre/bin/java
    chmod +x "${PATH_BATCH_WORKING}"/bin/MilesCLI.sh
    cp "${PATH_BATCH_WORKING}"/properties/install/* "${PATH_BATCH_WORKING}"/properties

    #deploy
    cp -R "${PATH_BATCH_WORKING}"/* "${jboss_home_cli}"

    #copy our configs
    cp "${config_home_cli}"/* "${jboss_home_cli}"/properties
fi
######################################################################################
#Server

copy_connector_install_xml() {
    xml_file=${PATH_CONNECTORS}/$1
    echo "xml_file: ${xml_file}"

    if [ -f "${xml_file}" ]; then
        cp "${xml_file}" "${PATH_CONNECTORS}"
        echo "file copied"
    else
        echo "file not found"
    fi
}

if [ "${RUN_SERVER_UPGRADE}" -eq 1 ]; then
    echo "Running server upgrade."

    PATH_SERVER="${PATH_ROOT}"/server
    PATH_SERVER_WORKING="${PATH_SERVER}"/working
    mkdir "${PATH_SERVER_WORKING}"
    unzip_patch_file "${PATH_SERVER}" "milesroot_${deployment_sofico_country_prefix}_${RELEASE}_${BUILD}*.zip" "${PATH_SERVER_WORKING}"
    copy_patch_file "${PATH_SERVER}" "server_${deployment_sofico_country_prefix}_JBOSS_${RELEASE}_${BUILD}*.ear" "miles.ear"

    #do nothing with workmanager
    #TODO: Remove workmanager from .zip? Maybe include this when we automatically download patches

    #create folder for properties file
    if [ ! -d "${PATH_SERVER_WORKING}"/properties ]; then
        mkdir "${PATH_SERVER_WORKING}"/properties
    fi

    #copy the properties for MMC
    cp -R "${PATH_SERVER_WORKING}"/mmc/install/* "${PATH_SERVER_WORKING}"/mmc

    #copy the install connector files only during the initial installation
    PATH_CONNECTORS="${PATH_SERVER_WORKING}"/connectors
    if [ "${UPGRADE}" == 0 ]; then
        cp -R "${PATH_CONNECTORS}"/install/* "${PATH_SERVER_WORKING}"/connectors/
    fi

    #copy specific connector install files
    copy_connector_install_xml ACLSE_Exact_Sales_Export/install/ACLSE_Exact_Sales_Export.xml
    copy_connector_install_xml SOF_CAP_RV_Import/install\ -\ CSV/SOF_CAP_RV_Import.xml
    copy_connector_install_xml SOF_CardNumber_TPSC_Import/install/SOF_CardNumber_TPSC_Import.xml
    copy_connector_install_xml SOF_Odometer_CostCenterEvent_Import/install/SOF_Odometer_CostCenterEvent_Import.xml
    copy_connector_install_xml UK_CAP_CAR_Vehicle_Import/install\ -\ CSV\ 2019/UK_CAP_CAR_Vehicle_Import.xml
    copy_connector_install_xml UK_CAP_LCV_Vehicle_Import/install\ -\ CSV\ 2019/UK_CAP_LCV_Vehicle_Import.xml
    copy_connector_install_xml UpdateLookupTablesForLookupTableDefinition/install/UpdateLookupTablesForLookupTableDefinition.xml

    #copy image maps
    cp -R "${PATH_SERVER_WORKING}"/documents/imagemap/install/* "${PATH_SERVER_WORKING}"/documents/imagemap/

    # overwriting the default ProductConfig.xml from the Sofico Miles patch with a country specific ProductConfig<countryname>.xml from the Sofico Miles patch
    if [ -f "${PATH_SERVER_WORKING}"/milesweb/install/ProductConfig"${clean_country_full}".xml ]; then
        cp -R "${PATH_SERVER_WORKING}"/milesweb/install/ProductConfig"${clean_country_full}".xml "${PATH_SERVER_WORKING}"/milesweb/ProductConfig.xml
    fi

    # overwriting the ProductConfig.xml from the Sofico Miles patch (default or country specific see above) with a file coming from our repository
    if [ -f "${deployment_override_productconfig_home}"/ProductConfig"${clean_country_full}".xml ] && [ "${deployment_override_productconfig_enabled}" == "TRUE" ]; then
        cp -R "${deployment_override_productconfig_home}"/ProductConfig"${clean_country_full}".xml "${PATH_SERVER_WORKING}"/milesweb/ProductConfig.xml
    fi

    if [ -f "${deployment_override_webproperties_home}"/WebProperties"${clean_country_full}".xml ] && [ "${deployment_override_webproperties_enabled}" == "TRUE" ]; then
        cp -R "${deployment_override_webproperties_home}"/WebProperties"${clean_country_full}".xml "${PATH_SERVER_WORKING}"/milesweb/WebProperties.xml
    fi

    #creating connector sub directories
    #these are also created by Miles for the first usage, but we create them earlier to prevent errors for the MFT jobs
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Autofocus_International_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Exact_Creditor_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Exact_Debtor_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Exact_Purchases_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Exact_Sundry_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACLSE_Exact_Sales_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Exact_Sales_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Remarketing_Purchasers_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/ACL_Remarketing_FleetVehicles_Export/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/SOF_Generic_Cost_Import/DONE
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/SOF_Generic_Cost_Import/ERROR
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/UK_KwikFit_Fleet_Export_v5/DONE

    #creating connector directories that Miles is expecting, but not creating automatically
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/UK_CAP_CAR_Vehicle_Import/inputfiles
    mkdir -p "${PATH_SERVER_WORKING}"/connectors/UK_CAP_LCV_Vehicle_Import/inputfiles

    #deploy
    cp -R "${PATH_SERVER_WORKING}"/* "${data_miles_home}"
    cp "${PATH_SERVER}"/miles.ear "${jboss_core_standalone_deployments}"/
    cp "${PATH_SERVER}"/workmanager-ra.rar "${jboss_core_standalone_deployments}"/

    #copy our configs
    cp "${core_boot_properties}" "${data_miles_home}"/properties/
    #mmc
    cp "${core_environments}" "${data_miles_home}"/mmc/resources/
    cp "${core_log4j}" "${data_miles_home}"/mmc/

    ######################################################################################
    ### Creation of Hard Symbolic link - data/<country>/milesroot/MilesServerStartup.log --> /data/<country>/logs/core
    # Function Hardlink Creation script
    symbolic_creation() {
        echo "Info: Creating Symbolic Link - ${log_core_home}/MilesServerStartup.log"
        ln "${data_miles_home}"/MilesServerStartup.log "${log_core_home}"
    }
    touch "${data_miles_home}/MilesServerStartup.log"
    if [ -f "${log_core_home}/MilesServerStartup.log" ]; then
        if [ "$(stat -c %h -- "${log_core_home}/MilesServerStartup.log")" -eq 1 ]; then
            echo "Warn: Filesystem has file with same name - ${log_core_home}/MilesServerStartup.log, Script proceeding to delete this file and fix conflict"
            rm -rf "${log_core_home}/MilesServerStartup.log"
            symbolic_creation
        fi # Hardlink existence check
    else
        symbolic_creation
    fi # File existence check

    ######################################################################################
fi
######################################################################################

######################################################################################
#RIA
if [ "${RUN_RIA_UPGRADE}" -eq 1 ]; then

    echo "Running ria upgrade."

    PATH_RIA="${PATH_ROOT}"/ria
    PATH_RIA_WORKING="${PATH_RIA}"/working
    mkdir "${PATH_RIA_WORKING}"
    unzip_patch_file "${PATH_RIA}" "milesriaroot_${RELEASE}_${BUILD}*.zip" "${PATH_RIA_WORKING}"
    copy_patch_file "${PATH_RIA}" "milesria_${RELEASE}_${BUILD}*.ear" "milesria.ear"

    #deploy
    cp -R "${PATH_RIA_WORKING}"/* "${data_milesria_home}"
    cp "${PATH_RIA}"/milesria.ear "${jboss_ria_standalone_deployments}"

    #copy our configs
    cp "${ria_boot_properties}" "${data_milesria_home}"/properties/
    cp "${ria_client_properties}" "${data_milesria_home}"/properties/
    ######################################################################################
fi
######################################################################################

######################################################################################
#WEB

copy_language_file() {
    source_file_name="$1"
    echo "source_file_name: ${source_file_name}"

    source_file="${language_source_path}"/"${source_file_name}"
    destination="${PATH_WEB_WORKING}"/config_"${newname}"/"${source_file_name}"

    if [ -f "${source_file}" ]; then
        cp -R "${source_file}" "${destination}"
        echo "file copied"
    else
        echo "file not found"
    fi
}

override() {
    file_name=$1
    override_enabled=$2
    source_file="${deployment_override_home}/${file_name}/${newname}/${file_name}_${clean_country_full}.xml"

    # This is needed in case we switch from "enabled overriding" to "disabled overriding"
    echo "Delete old ${data_milesweb_home}/config_${newname}/${file_name}.xml"
    rm -f "${data_milesweb_home}/config_${newname}/${file_name}.xml"

    if [ -f "${source_file}" ] && [ "${override_enabled}" == "TRUE" ]; then
        echo "Deploying: ${source_file}"
        cp -R "${source_file}" "${PATH_WEB_WORKING}/config_${newname}/${file_name}.xml"
    fi
}

deploy_milesweb() {
    echo "deploy_milesweb"

    milesweb_type="$1"
    echo "milesweb_type: ${milesweb_type}"

    milesweb_version="${deployment_sofico_country_prefix}"_"${milesweb_type}"
    # trim trailing "_" for broker version
    milesweb_version="${milesweb_version%_}"

    #checking if a country specific version exists
    find_patch_file "${PATH_WEB}" "web_${milesweb_version}_${RELEASE}_${BUILD}*.zip"

    #tmpvar set in 'find_patch_file'
    if [ ! -f "${tmpvar}" ]; then
        #remove country code from variable
        milesweb_version=ACL_"${milesweb_type}"
        # trim trailing "_" for broker version
        milesweb_version="${milesweb_version%_}"

        #try again to find a patch file with updated 'milesweb_version'
        find_patch_file "${PATH_WEB}" "web_${milesweb_version}_${RELEASE}_${BUILD}*.zip"
    fi

    #tmpvar set in 'find_patch_file'
    if [ -f "${tmpvar}" ]; then
        unzip "${tmpvar}" -d "${PATH_WEB_WORKING}"
    else
        if !( ([ "${country}" = "uk" ] || [ "${country}" = "prep" ]) && [ -z "${milesweb_type}" ] ); then
            echo "no ${milesweb_type} .zip available for ${country} to unzip, hence aborting the deployment"
            exit 1
        fi
        echo "no broker.zip available for ${country} to unzip, still proceeding with the deployment"
        return
    fi

    #rename default folders
    # todo: check usage of 'milesweb_type'. check if it is possible to switch that to 'newname'
    # in case that the usage of 'milesweb_type' can be changed to 'newname', we don't need 'newname' anymore
    # instead we can just change the value of 'milesweb_type'
    # ... otherwise just find a better name for the variable, than 'newname'
    newname=fleet
    if ( [ "${environment}" == "tst" ] && [ "${milesweb_type}" == "POS" ]); then
        newname=broker-mri
    fi
    if [ -z "${milesweb_type}" ]; then
        newname=broker
    fi
    echo "newname: ${newname}"

    if [ -d "${PATH_WEB_WORKING}"/config_"${milesweb_version}"/ ]; then
        mv "${PATH_WEB_WORKING}"/config_"${milesweb_version}"/ "${PATH_WEB_WORKING}"/config_"${newname}"
    fi

    #put files in place to overrule the default files from Sofico within the .war file
    echo "overrule default files:"

    echo "webmappings.xml"
    override "webmappings" "${deployment_override_webmappings_enabled}"

    # With Jira CCM-3770 we switched the approach to control the menu structure via RIA LookupTable configuration
    # To get rid of the old file configuration on the server we need to delete the files
    # It is done via this line to avoid having a separate manual step executed by e.g. DXC/Infosys
    # When the build containing this was deployed on all PRD environments, the next 2 lines can be removed
    echo "Delete ${data_milesweb_home}/config_*/menuitems.xml"
    rm -f "${data_milesweb_home}"/config_*/menuitems.xml

    echo "language_*.xml"
    # delete old files just in case the overruling is getting deactivated again
    # or in case that we don't want to overwrite certain files anymore
    rm -f "${data_milesweb_home}"/config_*/language*.xml

    # don't overwrite language files for broker-mri/POS
    if [ "${deployment_override_language_enabled}" == "TRUE" ] && [ "${milesweb_type}" != "POS" ]; then

        # default path used for (ACL-) broker
        language_source_path="${deployment_override_language_home}"
        # different path for fleet
        if [ "${milesweb_type}" == "FLEET" ]; then
            language_source_path="${deployment_override_language_home}"/fleet
        fi

        # language_<localLanguageCode>.xml
        # for most countries the language code is equal to the country code
        language_code="${clean_country}"

        # for Sweden country and language codes are different
        if [ "${clean_country}" == "se" ]; then
            language_code="sv"
        fi

        # todo: check if it cause any issues to copy always all language files
        # always copy english
        copy_language_file language_en.xml
        copy_language_file language_en_EN.xml
        # in addition copy the language for the country
        copy_language_file language_"${language_code}".xml
    fi
    # end of overruling default files

    #deploy
    if [ -f "${PATH_WEB_WORKING}"/war/"${milesweb_version}".war ]; then
        cp "${PATH_WEB_WORKING}"/war/"${milesweb_version}".war "${jboss_web_standalone_deployments}"/"${newname}".war
    fi
}

if [ "${RUN_WEB_UPGRADE}" -eq 1 ]; then
    echo "Running web upgrade."

    PATH_WEB="${PATH_ROOT}"/web
    PATH_WEB_WORKING="${PATH_WEB}"/working
    mkdir "${PATH_WEB_WORKING}"
    
    #deploy broker-mri only to tst
    if [ "${environment}" == "tst" ]; then
       deploy_milesweb "POS"
    fi
    deploy_milesweb "FLEET"
    # "" = Athlon Broker
    deploy_milesweb ""

    #deploy
    cp -R "${PATH_WEB_WORKING}"/* "${data_milesweb_home}"/
    cp "${config_home_web}"/empty.jpg "${web_carpic_image_home}"

    #copy our configs
    if [ -d "${data_web_config_broker}" ]; then
        cp "${web_config_broker}" "${data_web_config_broker}"/config.xml
        cp "${web_log4j_broker}" "${data_web_config_broker}"/log4j.xml
    fi
    cp "${web_config_fleet}" "${data_web_config_fleet}"/config.xml
    cp "${web_log4j_fleet}" "${data_web_config_fleet}"/log4j.xml
    if [ -d "${data_web_config_ACL}" ]; then
        cp "${web_config_ACL}" "${data_web_config_ACL}"/config.xml
        cp "${web_log4j_ACL}" "${data_web_config_ACL}"/log4j.xml
    fi
fi
######################################################################################

######################################################################################
#Database
if [ "${RUN_DATABASE_UPGRADE}" -eq 1 ]; then
    echo "Running database upgrade."

    echo "Checking the current Miles release"
    sqlplus -s "${db_user}"/"${db_pass}"@"${db_connectionstring}" < ../scripts_database/get_miles_release.sql

    # .log created within the above .sql
    miles_release_log=get_miles_release.log
    CUR_REL=$(sed '/^$/d' ${miles_release_log})
    # remove trailing white space
    CUR_REL=$(echo "${CUR_REL}" | sed 's/ *$//g')
    # file only used temporarily to extract release into variable
    rm "${miles_release_log}"

    # if the release to be deployed is equal to the current release, just continue
    if [ "${RELEASE}" != "${CUR_REL}" ]; then

        if [ "$(echo "${RELEASE} > ${CUR_REL}" | bc)" -eq 1 ]; then
            echo "DEBUG: New release ${RELEASE} higher than current release ${CUR_REL}"

            if [ "${do_release_upgrade:-false}" == "true" ]; then
                echo "INFO: Proceeding with DB release upgrade!"
            else
                echo "ERROR: In order to do the DB release upgrade the argument '-release-upgrade' must be added"
                exit 1
            fi
        else
            echo "WARNING: The new/patch Miles release is lower than the current Miles release."
            echo "That is not expected to happen. Please double check!"
            exit 1
        fi
    else
        echo "INFO: Current Miles release is equal to the patch release, deployment continues."
    fi

    #run security script, in case this script is calles directly, and not from deploy_country.sh
    #su ${user} security.sh

    PATH_DATABASE="${PATH_ROOT}"/database
    PATH_DATABASE_WORKING="${PATH_DATABASE}"/working
    mkdir "${PATH_DATABASE_WORKING}"
    unzip_patch_file "${PATH_DATABASE}" "database_${deployment_sofico_country_prefix}_${RELEASE}_${BUILD}*.zip" "${PATH_DATABASE_WORKING}"

    chmod +x "${PATH_DATABASE_WORKING}"/*.sh
    DATE=$(date +%Y-%m-%d_%H.%M.%S)
    DB_LOG_FILE="${data_logs_home}"/deployment/sofico_database_update_"${country}"_"${RELEASE}"_"${BUILD}".log
    echo "${DATE}" >> "${DB_LOG_FILE}"
    sqlplus "${db_user}"/"${db_pass}"@"${db_connectionstring}" < ../scripts_database/update_syskeytables.sql
    cd "${PATH_DATABASE_WORKING}"/
    ./updateMilesDB.sh "${db_user}" "${db_pass}" "${db_connectionstring}" "${RELEASE}" >> "${DB_LOG_FILE}"
    cd "${DIR}"
    DATE=$(date +%Y-%m-%d_%H.%M.%S)
    echo "${DATE}" >> "${DB_LOG_FILE}"
fi
######################################################################################

#clean when done
rm -rf "${deploy_tmp_home}"/extracted_build

DATE=$(date +%Y-%m-%d_%H.%M.%S)
version_log_message="${DATE} : "
version_log_message+="${deployment_sofico_country_prefix} : "
version_log_message+="${RELEASE} : "
version_log_message+="${DELIVERY}"
echo "${version_log_message}" >> "${version_miles_acl}"
