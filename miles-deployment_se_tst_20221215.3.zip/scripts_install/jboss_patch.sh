#!/bin/bash

# patch_zip_file

SERVER_TYPE_APP="-a"
SERVER_TYPE_WEB="-w"

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

run_patch()
{
    source jboss-cli.sh "patch apply ${1}"
}

PARAMS_OK=1
if [ "$#" -lt 1 ] || [ "$#" -gt 2 ]; then
    PARAMS_OK=0
fi

#check if patch file exists
PATCH_FILE="$1"
if [ ! -f "${PATCH_FILE}" ]; then
    echo "wrong argument: patch file does not exist"
    PARAMS_OK=0
fi

#check if app or web is passed
source sub/server_role.sh
SERVER_TYPE="${server_role}"

if [ "${PARAMS_OK}" -ne 1 ]; then
    echo ""
    echo "USAGE: jboss_patch.sh patch_file"
    exit
fi

if [  "${SERVER_TYPE}" == "${SERVER_TYPE_WEB}" ]; then
  cd "${jboss_web_bin_home}" || { echo "cd ${jboss_web_bin_home} failed"; exit; }
  run_patch "${PATCH_FILE}"
fi

if [  "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ]; then
  cd "${jboss_core_bin_home}" || { echo "cd ${jboss_core_bin_home} failed"; exit; }
  run_patch "${PATCH_FILE}"

  cd "${jboss_ria_bin_home}" || { echo "cd ${jboss_ria_bin_home} failed"; exit; }
  run_patch "${PATCH_FILE}"
fi

cd || { echo cd to jboss bin directory failed; exit; }
#source restart_country_${country}.sh

./jboss-cli.sh "patch apply /data/deployment/bin/jboss-eap-7.1.6-patch.zip"
