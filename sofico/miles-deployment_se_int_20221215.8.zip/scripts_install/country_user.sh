#!/bin/bash

# create env xml file
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

id -u "${country_user}" >/dev/null 2>&1 || sudo useradd -m "${country_user}"

sudo usermod -a -G "${group}" "${country_user}"

if [  "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ]; then
    # Only needed on the APP server as we make use of a NFS share
    sudo usermod -a -G miles_vehicle_data "${country_user}"
fi

usermod -aG wheel "${country_user}"
