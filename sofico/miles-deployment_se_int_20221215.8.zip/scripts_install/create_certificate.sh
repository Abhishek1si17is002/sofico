#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

keytool -genkeypair -alias "${ria_name}" -storetype jks -keyalg RSA -keysize 2048 -keypass "${ria_passphrase}" -keystore "${ria_certificate_file_full}" -storepass "${ria_passphrase}" --dname "CN=Athlon, OU=Athlon, O=athlon.com, L=Almere, C=NL"
