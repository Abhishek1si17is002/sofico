#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

if [ "$1" == "-a" ]
then
    sudo chown -R "${country_user}":"${group}" "${jboss_home_core}"
    sudo chown -R "${country_user}":"${group}" "${jboss_home_ria}"
    sudo chown -R "${country_user}":"${group}" "${jboss_home_cli}"
fi

if [ "$1" == "-w" ]
then
    sudo chown -R "${country_user}":"${group}" "${jboss_home_web}"
fi

sudo chown -R "${country_user}":"${group}" "${data_home}"/"${country}"
