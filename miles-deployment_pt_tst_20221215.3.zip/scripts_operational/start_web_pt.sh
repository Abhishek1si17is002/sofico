#!/bin/bash

systemctl start milesweb-pt.service

ps -aux | grep "jboss-pt"

deployment_path="/app/milesweb-pt/standalone/deployments"

# deployments in all countries
files_to_check="${deployment_path}/fleet.war"

# deployment of broker-mri only in TST
if [ "${environment}" == "tst" ]; then
       files_to_check+=" ${deployment_path}/broker-mri.war"
fi

# deployment in all countries except UK (prep=UK)
if [ "pt" != "uk" ] && [ "pt" != "prep" ]; then
    files_to_check+=" ${deployment_path}/broker.war"
fi

# no <"> arround ${files_to_check} because the content should be passed as multiple arguments
/home/jboss-pt/check_jboss_startup.sh ${files_to_check}
