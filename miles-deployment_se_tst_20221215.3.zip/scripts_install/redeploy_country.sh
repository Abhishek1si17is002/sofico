#!/bin/bash

#Redeploy Script for Miles
#In this script I will search for the last file deployed in /data/deployment/{country}/version.txt file
#Inside the file I will look for the variable deployed_file and take the last deployed file in Miles
#After I know the file I just execute the ./deploy_country.sh script

#Variable where I will take the last deployed file
# loading variables
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env
#use variables to calculate the path
version_file_path="${deployment_home}/${country}/version.txt"
#Variable for the last deployed file
deployed_file=""
#Variable to search inside version_file_path
var_name="deployed-file"
#Log variables
DATE=$(date +%Y-%m-%d_%H.%M.%S)
LOG_FILE="${data_logs_home}"/deployment/redeploy_"${DATE}".log

function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

#check if the file exists
if test ! -f "${version_file_path}" ; then
    print_log_message ERROR "${version_file_path} NOT FOUND! - Redeploy not possible, please do a normal deployment using the 'deploy_country.sh' script\n" | tee "${LOG_FILE}"
    exit 1
fi

print_log_message INFO "file ${version_file_path} found!" | tee "${LOG_FILE}"

deployed_file=$(grep "^${var_name}=" "${version_file_path}" | cut -d"=" -f2)

#if the variable is empty in version.txt check for the variable in version_backup.txt
if [ -z "${deployed_file}" -o "${deployed_file}" == "#{deployed_file}#" ]; then
    deployed_file=$(grep "^${var_name}=" "${version_backup_file_path}" | cut -d"=" -f2)
    #if the variable is empty in version_backup then ERROR
    if [ -z "${deployed_file}" -o "${deployed_file}" == "#{deployed_file}#" ]; then
        print_log_message ERROR "ERROR! Deployed file variable not FOUND! in ${version_file_path}. Please, use the normal deployment script with the Miles patch file as argument\n" | tee "${LOG_FILE}"
        exit 1
    fi
fi

if [ "$#" -lt 1 ];
then
    print_log_message INFO "Execute ./deploy_country ${deployed_file} \n" | tee "${LOG_FILE}"
    "${DIR}"/deploy_country.sh "${deployed_file}"
else
    print_log_message INFO "Execute ./deploy_country ${deployed_file} -b $1 \n" | tee "${LOG_FILE}"
    "${DIR}"/deploy_country.sh "${deployed_file}" -b "$1"
fi
exit 0
