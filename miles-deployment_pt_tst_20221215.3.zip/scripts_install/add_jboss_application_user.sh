#!/bin/bash

# create env xml file
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

cd "${jboss_core_bin_home}" || { echo "cd ${jboss_core_bin_home} failed"; exit; }
source add-user.sh -a --silent=true ejb XXXjboss_application_user_ejbYYY
cd "${DIR}" || { echo "cd ${DIR} failed"; exit; }
