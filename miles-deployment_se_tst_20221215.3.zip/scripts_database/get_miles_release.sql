SPOOL get_miles_release.log
SET HEADING OFF
SELECT value FROM sysversion WHERE name = 'DB_VERSION';

SPOOL OFF
EXIT
