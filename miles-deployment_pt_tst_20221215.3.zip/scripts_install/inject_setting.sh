#!/bin/bash

#############################################################################################################
# check if we have any parameters
#############################################################################################################
#if [ $# -ne 2 ]
if [ $# -lt 2 ]
then
    echo "Please provide two parameters."
    echo "1. input file"
    echo "2. property file"
    exit 1
fi
INPUT_FILE="${1}"
PROPERTY_FILE="${2}"

DEBUG=0
if [ "${3}" == "-v" ]
then
	DEBUG=1
fi

#############################################################################################################
# create placeholder output file
#############################################################################################################
if [ "${DEBUG}" == 1 ]
then
        echo "replacing text in '${INPUT_FILE}'"
fi
cp "${INPUT_FILE}" "${INPUT_FILE}".bak

#############################################################################################################
# iterate through property file and replace step by step all "properties" with the "value"
#############################################################################################################
cat "${PROPERTY_FILE}" | while read -r LINE
do
	PROPERTY=${LINE%%=*}
	if [ -z "${PROPERTY}" ]
	then
		continue
	fi
	VALUE=${LINE#$PROPERTY=}
	cp "${INPUT_FILE}" "${INPUT_FILE}".tmp
	cat "${INPUT_FILE}".tmp | sed -e "s:${PROPERTY}:${VALUE}:g" > "${INPUT_FILE}"
	rm -f "${INPUT_FILE}".tmp
done