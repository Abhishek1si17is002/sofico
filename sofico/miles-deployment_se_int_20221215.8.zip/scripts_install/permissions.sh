#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

find "${jboss_home}"/ -type f -exec chmod "${permission}" {} +
find "${jboss_home}"/ -type d -exec chmod "${permission_country}" {} +

find "${data_home}"/"${country}" -type f -exec chmod "${permission}" {} +
find "${data_home}"/"${country}" -type d -exec chmod "${permission_country}" {} +

if [ -d "${log_cli_home}" ]; then
    chmod g+s "${log_cli_home}"
fi
