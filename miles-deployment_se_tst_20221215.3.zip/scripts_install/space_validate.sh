#!/bin/sh

# This script validates the available free disk space for the provided mount points with given threshold.
# For any new mount point required to be checked add them to "fs_collection".

################################################################################
# loading variables
DIR=$(dirname "${0}")
. "${DIR}"/../config/instance.env

################################################################################

server_role="$1"

# Files systems to check for free space - Array format (Filesystem:MinimumFreespaceinKB)
# Specified in KB - 100mb
country_mount_point="/dev/mapper/vgdata-lvdata--${country}:102400"
# Specified in KB - 10mb
home_mount_point="/dev/mapper/vghome-lvhome:10240"

if [[ "${server_role}" == "-a" ]]; then
    # Specified in KB - 1.75gb
    data_mount_point="/dev/mapper/vgdata-lvdata:1835008"
    # Specified in KB - 3.5gb
    app_mount_point="/dev/mapper/vgapp-lvapp:3670016"
    fs_collection=("${data_mount_point}" "${country_mount_point}" "${home_mount_point}" "${app_mount_point}")
elif [[ "${server_role}" == "-w" ]]; then
    # Specified in KB - 1.5gb
    data_mount_point="/dev/mapper/vgdata-lvdata:1572864"
    # Specified in KB - 1gb
    app_mount_point="/dev/mapper/vgapp-lvapp:1048576"
    fs_collection=("${data_mount_point}" "${home_mount_point}" "${app_mount_point}")
fi

for fs in ${fs_collection[@]}; do
    arrfs=(${fs//:/ })
    # Records Available space ($4) and Mount Point name ($6)
    manipulation=$(df "${arrfs[0]}" | awk '{ print $6 " " $4 }' | tail -n 1)
    avail_fspace=$(echo "${manipulation}" | awk '{ print $2}' )
    mount_point=$(echo "${manipulation}" | awk '{ print $1}')
    if (( "${avail_fspace}" < ${arrfs[1]} )); then
        echo "WARNING: Running out of space on mount point ---> ${mount_point} ---> Only available (${avail_fspace}) ---> Minimum required (${arrfs[1]})"
    fi
done
