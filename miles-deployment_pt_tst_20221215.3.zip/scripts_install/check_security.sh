cat ../config/core/standalone-full.xml  | grep "<password>"

cat ../config/ria/standalone-full.xml | grep "secret value"

cat ./../scripts_database/2.2_create_galaxy_users.sql | grep "IDENTIFIED BY "

cat ./../scripts_database/7_create_cardata_user.sql | grep "IDENTIFIED BY "

cat add_jboss_application_user.sh | grep "add-user"

cat ./../config/instance.env | grep "db_pass"

cat ../config/core/boot.properties | grep "interfacePWD"

cat ../config/core/boot.properties | grep "documents.jasper.db.password"

cat ../config/xml/ame_documents.xml | grep "com.athloncarlease.miles.jdbc.galaxy.web.password"

cat ../config/xml/ame_documents.xml | grep "com.athloncarlease.miles.jdbc.galaxy.pro.password"

cat ../config/xml/ame_documents.xml | grep "com.athloncarlease.miles.db.system.password"