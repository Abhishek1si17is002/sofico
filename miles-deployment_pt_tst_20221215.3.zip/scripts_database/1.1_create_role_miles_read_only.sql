/* ************************* Create roles */

CREATE ROLE MILES_READ_ONLY NOT IDENTIFIED;