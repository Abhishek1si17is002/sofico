echo 'check if jboss was stopped'
ps -aef | grep /app/miles-se | grep -v grep | grep -v miles_ria_se | grep -v miles_web_se | grep -v $0 | awk '{print $2}' > /app/miles-se/bin/stop.check

for i in `cat /app/miles-se/bin/stop.check`
do
    echo "kill process"
    kill -9 $i
done
sleep 5
echo 'clean temp files'
rm -rf /app/miles-se/standalone/tmp/*
rm -rf /app/miles-se/standalone/data/*
rm -f /app/miles-se/bin/stop.check