-- Italy
UPDATE syskeyrange SET low = 450000, high = 474999 WHERE syskeyrange_id = 1;
UPDATE syskeyrange SET low = 550000, high = 599999 WHERE syskeyrange_id = 2;
UPDATE syskeytable2 SET start_id = 550000 WHERE start_id != 550000;
UPDATE syskeytable2 SET last_id = 550000 WHERE last_id < 550000;
commit;