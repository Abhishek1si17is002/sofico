UPDATE connectionprofile
   SET name = 'pt_tst',
       syskeyrange_id = 3,
       isenabled = 1
 WHERE connectionprofile_id = 1;

COMMIT;