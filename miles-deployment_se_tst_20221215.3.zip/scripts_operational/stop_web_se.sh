#!/bin/bash



systemctl stop milesweb-se.service

ps -aux | grep "jboss-se"