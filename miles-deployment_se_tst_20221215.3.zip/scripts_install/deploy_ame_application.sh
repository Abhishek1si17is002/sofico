#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

if [ "$(whoami)" != "${country_user}" ]; then
    echo "Script must be run as user: ${country_user}"
    exit -1
fi

if [[ $# -eq 0 ]] ; then
    echo 'please provide a version to install'
    exit 1
fi

DATE=$(date +%Y-%m-%d_%H.%M.%S)
LOG_FILE="${data_logs_home}"/deployment/deploy_application_"${DATE}".log

jarfile="${deployment_home}"/ame/miles-installer-"$1".jar
configfile="${deployment_home}"/"${country}"/config/xml/ame_application.xml

if [ -e "${jarfile}" ]
then
    echo "ok"
else
    #echo "nok"
    echo "the following jar file is not found: " "${jarfile}"
    exit 1
fi

if [ -e "${configfile}" ]
then
    echo "ok"
else
    #echo "nok"
    echo "the following config file is not found: " "${configfile}"
    exit 1
fi

cd "${data_logs_home}"/deployment/ame/application || { echo "cd ${data_logs_home}/deployment/ame/application failed"; exit; }

java -jar "${jarfile}" "${configfile}" |& tee -a "${LOG_FILE}"

cd "${DIR}" || { echo "cd ${DIR} failed"; exit; }

echo "${DATE}" : "$1" > "${version_ame_miles_installer}"
