#!/bin/bash

################################################################################
# Attention: 
# Run this script without argument to only refresh an environment and no DB patch level update
# Run this script with "-db-update" argument to update DB patch level along with the other after DB refresh activites
################################################################################

#after_db_refresh shell script to perform after db refresh activities for MILES
#this script performs the following tasks:
# - Rerun script to set permissions for Miles tables for the MILES_READ_ONLY DB role
# - Renaming connection profile
# - Creating milesweb test users
# - Reinstall MILES documents
# - Reinstall Sofico Patch

################################################################################
# loading variables
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

################################################################################
deployment_miles_document_path="${data_logs_home}/deployment/deployment_ame_miles_reporting.txt"
#Log variables
DATE=$(date +%Y-%m-%d_%H.%M.%S)
LOG_FILE="${data_logs_home}"/deployment/after_db_refresh_"${DATE}".log

if [ "${environment}" == "prd" ]; then
    echo "executing after_db_refresh.sh script is not allowed on PRD"
    exit 0
fi

function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

#Rerun script to set permissions for Miles tables for the MILES_READ_ONLY DB role and update connection profile name
print_log_message INFO "Execute ./exec_db_script.sh 3_role_miles_read_only_permissions.sql \n" | tee -a "${LOG_FILE}"
cd "${db_script_home}"
source exec_db_script.sh 3_role_miles_read_only_permissions.sql
print_log_message INFO "Execute ./exec_db_script.sh 5_update_mmc_name.sql \n" | tee -a "${LOG_FILE}"
source exec_db_script.sh 5_update_mmc_name.sql
print_log_message INFO "Execute ./exec_db_script.sh create_miles_web_test_user_procedure.sql \n" | tee -a "${LOG_FILE}"
source exec_db_script.sh create_miles_web_test_user_procedure.sql

if [ "${country}" == "it" ]; then
    print_log_message INFO "Execute ./exec_db_script.sh create_miles_web_test_users_it.sql \n" | tee -a "${LOG_FILE}"
    source exec_db_script.sh create_miles_web_test_users_it.sql
elif [ "${country}" == "es" ]; then
    print_log_message INFO "Execute ./exec_db_script.sh create_miles_web_test_users_es.sql \n" | tee -a "${LOG_FILE}"
    source exec_db_script.sh create_miles_web_test_users_es.sql
else
    print_log_message INFO "Execute ./exec_db_script.sh create_miles_web_test_users.sql \n" | tee -a "${LOG_FILE}" 
    source exec_db_script.sh create_miles_web_test_users.sql
fi

#get deployed_ame_miles_reporting file version number from deployment_ame_miles_reporting.txt file
deployed_miles_documents_version=$(grep -oE '[^ ]+$' "${deployment_miles_document_path}")

#Reinstall MILES documents
cd "${app_script_home}"
print_log_message INFO "Execute ./deploy_ame_documents.sh ${deployed_miles_documents_version} \n" | tee -a "${LOG_FILE}"
(su "${country_user}" deploy_ame_documents.sh ${deployed_miles_documents_version}) |& tee -a "${LOG_FILE}"

#Reinstall sofico patch in case argument is given
if [ "$#" -eq 1 ] && [ "${1}" == "-db-update" ]; then
    print_log_message INFO "Execute ./redeploy_country \n" | tee -a "${LOG_FILE}"
    "${DIR}"/redeploy_country.sh
fi
