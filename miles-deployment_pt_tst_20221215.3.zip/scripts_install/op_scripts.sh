#!/bin/bash

# create env xml file
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

# copy the operational scripts to jboss home
chmod +x ../scripts_operational/*.sh

server_type="app"

if [ "$1" == "-a" ]; then
    cp -n ../scripts_operational/deploy_all_app.sh ~/deploy_all.sh
fi

if [ "$1" == "-w" ]; then
    server_type="web"

    cp ../scripts_operational/unzip_jatocarimages.sh "${web_carpic_script_home}"/

    cp -n ../scripts_operational/deploy_all_web.sh ~/deploy_all.sh

    cp ../scripts_operational/check_milesweb_"${country}".sh ~/check_milesweb_"${country}".sh
fi

cp ../scripts_operational/start_"${server_type}"_"${country}".sh /home/"${country_user}"/start_country_"${country}".sh
cp ../scripts_operational/restart_"${server_type}"_"${country}".sh /home/"${country_user}"/restart_country_"${country}".sh
cp ../scripts_operational/stop_"${server_type}"_"${country}".sh /home/"${country_user}"/stop_country_"${country}".sh

cp ../scripts_operational/start_"${server_type}"_"${country}".sh ~/start_country_"${country}".sh
cp ../scripts_operational/restart_"${server_type}"_"${country}".sh ~/restart_country_"${country}".sh
cp ../scripts_operational/stop_"${server_type}"_"${country}".sh ~/stop_country_"${country}".sh

cp ../scripts_operational/check_jboss_startup.sh /home/"${country_user}"/
