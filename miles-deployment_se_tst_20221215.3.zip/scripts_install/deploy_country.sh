#!/bin/bash

################################################################################
# exit script on any error
set -euo pipefail

err_report() {
    echo >&2 '
***************
*** ABORTED ***
***************
'
    echo "An error occurred on line $(caller). Script aborted and exiting..." >&2
    exit 1
}

# send message if script is aborted
trap err_report ERR

################################################################################
# loading variables
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

################################################################################
# functions

# Setting up Deployment permissions
set_deployment_permission() {
    chown -R "${user}":"${group}" "${deployment_home}"
    chmod -R "${permission}" "${deployment_home}"
}

# Logging with time stamp
function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

################################################################################
# processing arguments

# fixed arguments
# 1: SOFICO RELEASE FILE
# optional arguments
# a: rerun install -reinstall OPTIONAL
SHOULD_REINSTALL=0
ENVIRONMENT_PROD="prd"
# b: build number for the config-files zip
BUILD_NUMBER=0

OTHER_ARGUMENTS=()
PARAMS_OK=1

# at least 1 arguments. not more than 3
if [ "$#" -lt 1 ] || [ "$#" -gt 3 ]; then
    PARAMS_OK=0
fi

#check if sofico file exists
SOFICO_FILE="$1"
if [ ! -f "${SOFICO_FILE}" ]; then
    echo "ERROR: wrong argument: Sofico deployment .zip file does not exist"
    PARAMS_OK=0
fi

# check if Sofico file name contains 'nightly'. abort deployments of 'nightly' patches on PRD
if [[ "${SOFICO_FILE,,}" == *"nightly"* ]] && [ "${environment}" == "${ENVIRONMENT_PROD}" ]; then
    echo "ERROR: Nightly Sofico deployment files are not allowed on PRD"
    PARAMS_OK=0
fi

################################################################################

# shift 1 argument which are fix, to allow further processing of the other arguments
shift 1

# Loop through arguments and process them
for arg in "$@"; do
    # stop loop if no arguments are left
    if [ "$#" -eq 0 ]; then
        break
    fi
    case "${arg}" in
    -reinstall)
        # prohibit performing a reinstall on production
        if [ "${environment}" == "${ENVIRONMENT_PROD}" ]; then
            PARAMS_OK=0
        else
            SHOULD_REINSTALL=1
        fi
        shift # Remove -reinstall from processing
        ;;
    -b | --build-number)
        if [ -n "${2:-}" ] && [ "${2:0:1}" != "-" ]; then
            BUILD_NUMBER="$2"
            shift 2 # Remove argument name and value from processing
            # creating an backup file for version.txt
            cp "${deployment_home}"/"${country}"/version.txt "${version_backup_file_path}"
        else
            echo "ERROR: Argument for $1 is missing" >&2
            PARAMS_OK=0
        fi
        ;;
    -release-upgrade)
        export do_release_upgrade="true"
        shift # Remove -release-upgrade from processing
        ;;
    *)
        OTHER_ARGUMENTS+=("$1")
        shift # Remove generic argument from processing
        ;;
    esac
done

if [ -n "${OTHER_ARGUMENTS-}" ]; then
    echo "WARNING: Not supported arguments provided: ${OTHER_ARGUMENTS[*]}"
fi

if [ "${PARAMS_OK}" -ne 1 ]; then
    echo ""
    echo "USAGE: deploy_country.sh sofico_file [-reinstall] [-b <build number>]"
    echo ""
    echo "-reinstall: [OPTIONAL] Not available on Prod!"
    echo ""
    echo "-b|--build-number: <number> [OPTIONAL]"
    echo ""
    exit 0
fi

################################################################################
# sets a flag ("-a" or "-w") hard coded depending on server name
source sub/server_role.sh
SERVER_TYPE="${server_role}"
SERVER_TYPE_APP="-a"
SERVER_TYPE_WEB="-w"

################################################################################
# Space_validate.sh - Aborts deployment if the free disk space requirements are not met

free_space_alarm=$(./space_validate.sh "${SERVER_TYPE}")
echo "${free_space_alarm}"
if [[ -n "${free_space_alarm}" ]]; then
    print_log_message ERROR "Free disk space requirements are not met - Aborting the deployment!"
    exit 1
fi

################################################################################
# start of real script after parameters are okay

DATE=$(date +%Y-%m-%d_%H.%M.%S)
LOG_FILE="${data_logs_home}"/deployment/deploy_"${DATE}".log
su "${user}" -c "mkdir -p ${data_logs_home}/deployment/"
touch "${LOG_FILE}"
version_config_log_path="${data_logs_home}"/version_config.log

################################################################################
# Stop server before continue with the deployment.
print_log_message INFO "Stoping ${country} Miles JBoss-Server" |& tee -a "${LOG_FILE}"
~/stop_country_${country}.sh |& tee -a "${LOG_FILE}"
print_log_message INFO "Miles JBoss-Server is stopped"|& tee -a "${LOG_FILE}"

################################################################################
# Update - Current installed version to log file

if [ -f "${version_config_log_path}" ]; then
    current_version=$(tail -n 1 "${version_config_log_path}")
    echo "INFO : Updating current installed version to the log file ------------ " |& tee -a "${LOG_FILE}"
    echo "Current installed version: ""${current_version}" |& tee -a "${LOG_FILE}"
else
    echo "INFO : Version Logging file ${version_config_log_path} not existis - unable to extract current installed version" |& tee -a "${LOG_FILE}"
fi

################################################################################
# remove old deployment to have a clean reinstallation

if [ "${SHOULD_REINSTALL}" -eq 1 ]; then
    #remove current release
    DATE=$(date +%Y-%m-%d_%H.%M.%S)
    echo "${DATE}"
    echo "removing current installation for " "${country}" |& tee -a "${LOG_FILE}"
    rm -rf "${data_miles_home}"
    rm -rf "${data_milesria_home}"
    rm -rf "${data_milesweb_home}"
    rm -rf "${jboss_home}"/miles-"${country}"
    rm -rf "${jboss_home}"/milesria-"${country}"
    rm -rf "${jboss_home}"/milescli-"${country}"
    rm -rf "${jboss_home}"/milesweb-"${country}"
    echo "Done removing current installation for " "${country}" && echo
fi

################################################################################
# loading new configuration files

if [ ! "${BUILD_NUMBER}" == "0" ]; then
    echo "INFO: config-file build number provided, starting updating now" |& tee -a "${LOG_FILE}"

    CONFIG_FILE="miles-deployment_${country}_${environment}_${BUILD_NUMBER}.zip"

    # unzip files to root country directory for the deployment files
    echo "unzipping config-file" |& tee -a "${LOG_FILE}"
    if [ -f "${deployment_config_files}/${CONFIG_FILE}" ]; then
        unzip -o "${deployment_config_files}"/"${CONFIG_FILE}" -d "${deployment_home}"/"${country}" |& tee -a "${LOG_FILE}"
        # set permissions, otherwise restarting of script would fail
        set_deployment_permission
    else
        echo "ERROR: ${CONFIG_FILE} was not found" |& tee -a "${LOG_FILE}"
        exit 1
    fi

    echo "*********************** starting script again ***********************" |& tee -a "${LOG_FILE}"
    "$0" "${SOFICO_FILE}" "${SERVER_TYPE}"

    # exit, to prevent that the script continues with the first set of arguments,
    # after it has already restarted itself again
    echo "exit"
    exit 0
else
    echo "INFO: No config-file build number provided" |& tee -a "${LOG_FILE}"
fi

################################################################################

set_deployment_permission

source jboss-upgrade.sh "${SERVER_TYPE}" |& tee -a "${LOG_FILE}"

#check if jboss_home/bin folder exists. in that case run an update
UPGRADE=0
if [ "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ] && [ -d "${jboss_core_bin_home}" ]; then
    # folder exists run upgrade
    echo "conditions to perform an upgrade are met."
    UPGRADE=1
fi

if [ "${SERVER_TYPE}" == "${SERVER_TYPE_WEB}" ] && [ -d "${jboss_web_bin_home}" ]; then
    # folder exists run upgrade
    echo "conditions to perform an upgrade are met."
    UPGRADE=1
fi

if [ "${UPGRADE}" == 0 ]; then

    if [ "${SERVER_TYPE}" == "${SERVER_TYPE_WEB}" ]; then
        # For MilesWeb the data_country_home is no mounting point and must be created
        su "${user}" -c "mkdir -p ${data_logs_home}"
    fi

    chown -R "${user}":"${group}" "${data_country_home}"
    chmod -R "${permission}" "${data_country_home}"
fi

################################################################################
# Exporting UPGRADE variable for other scripts to leverage - Currently its used in deploy_sofico_release.sh & space_validate.sh
export UPGRADE="${UPGRADE}"

################################################################################

#store current folder
DN="${PWD}"
echo "Current folder is: " "${DN}" |& tee -a "${LOG_FILE}"

source call_arg_script.sh true "creating folder structure" "folder_structure.sh" -- "${SERVER_TYPE}"

if [ "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ] && [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh true "copy settings file" "copy_setting.sh"
fi

if [ "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ]; then
    source call_arg_script.sh true "setting security" "security.sh"
fi

if [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh true "creating jboss instance" "jboss.sh" -- "${SERVER_TYPE}"
fi

if [ "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ] && [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh true "creating jdbc" "jdbc.sh"

    source call_arg_script.sh true "create certificate" "create_certificate.sh"
fi

source call_arg_script.sh true "distributing config files" "distribute_config_files.sh" -- "${SERVER_TYPE}"

if [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh true "creating logfiles" "logfiles.sh" -- "${SERVER_TYPE}"
fi

if [ "${SERVER_TYPE}" == "${SERVER_TYPE_APP}" ] && [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh true "creating ejb user" "add_jboss_application_user.sh"

    DATE=$(date +%Y-%m-%d_%H.%M.%S)
    echo "${DATE}" |& tee -a "${LOG_FILE}"
    echo "running database scripts for galaxy and jato" |& tee -a "${LOG_FILE}"
    cd "${DN}"
    cd ../scripts_database
    echo "${PWD}"
    su "${user}" run_db_scripts.sh |& tee -a "${LOG_FILE}"
    cd "${DN}"
    echo "finished running database scripts for galaxy and jato" |& tee -a "${LOG_FILE}" && echo
fi

source call_arg_script.sh true "deploy sofico release" "deploy_sofico_release.sh" -- "${SOFICO_FILE}" "${SERVER_TYPE}"

if [ "${UPGRADE}" == 0 ]; then
    source call_arg_script.sh false "creating country specific user" "country_user.sh"
fi

source call_arg_script.sh false "creating systemd services" "setup_service.sh" "${SERVER_TYPE}"

source call_arg_script.sh false "copy the operational scripts to country user's home" "op_scripts.sh" "${SERVER_TYPE}"

source call_arg_script.sh false "running flexible script" "flexible.sh" "${SERVER_TYPE}"

source call_arg_script.sh false "setting ownership for country user" "owner.sh" "${SERVER_TYPE}"

source call_arg_script.sh false "setting permissions" "permissions.sh"

################################################################################
# versioning script, this will update version.txt with Deploy Time
# and the last deployed file

./versioning.sh "${deployment_home}"/"${country}"/version.txt "${SOFICO_FILE}"

################################################################################

function readyProperty {
    grep "${1}" "${deployment_home}"/"${country}"/version.txt | cut -d'=' -f2
}

DATE=$(date +%Y-%m-%d_%H.%M.%S)
version_log_message="${DATE} - "
version_log_message+="git-commit: $(readyProperty 'git-commit') - "
version_log_message+="build-time: $(readyProperty 'build-time') - "
version_log_message+="build-number: $(readyProperty 'build-number') - "
version_log_message+="deployed-file: $(readyProperty 'deployed-file')"
# TODO: Check if it is needed to add a variable for the .log file name
echo "${version_log_message}" >> "${version_config_log_path}"
# removing version.backup file after the version.txt file is updated successfully and deployment script is successfull
rm -rf "${version_backup_file_path}"

################################################################################

# to prevent that the trap triggers
exit 0
