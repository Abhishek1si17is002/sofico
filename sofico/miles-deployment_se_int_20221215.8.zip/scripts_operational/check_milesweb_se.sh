#!/bin/bash

DATE=$(date +%Y-%m-%d)
LOG_FILE=/data/se/logs/web/site_check_${DATE}.log

login_page_failures=0

print_log_message() {
    echo -e "$(date '+%F %T')\t""${1}"
}

run_as_jboss_user() {
    sudo -u "jboss-se" "${@}"
}

check_site_endpoint() {
    print_log_message "checking ${1} ${2} page"
    code=$(curl -sS --head --request GET localhost:10042/"$app"/"${3}" --max-time 20 |& head -1)
    if echo "${code}" | grep "200 OK" >/dev/null; then
        print_log_message "${1} ${2} page reachable | ${code}"
    else
        print_log_message "${1} ${2} page unreachable | ${code}"
        if [[ ${2} == "login" ]]; then
            # temporary check to avoid restarting italy based on fleet
            if [[ ${1} == "broker" ]]; then
                ((login_page_failures++))
            fi
        fi
    fi
}

function main() {

    my_apps=("broker" "broker-mri" "fleet")
    
    # remove broker-mri as it is not deplyed to ACC/PRD
    if [ "${environment}" != "tst" ]; then
        unset 'my_apps[1]'
    fi
    # removing broker as it is not available in uk
    if [[ "se" == "uk" ]]; then
        unset 'my_apps[0]'
    fi

    for app in "${my_apps[@]}"; do
        check_site_endpoint  "$app"   "login"    "user/login.xhtml"
        check_site_endpoint  "$app"   "version"  "version.xhtml"
    done

    if [[ "$login_page_failures" -eq 0 ]]; then
        print_log_message "Miles Web is Up"
    else
        print_log_message "Miles Web is Down"
        PROC=$(
            echo
            echo "system overview:"
            date
            top -b -n 1 | head -n 5
            echo
            echo "jboss-se:"
            top -b -n 1 -c | grep "jboss-se"
        )
        print_log_message "${PROC}"
        # lookup URL for Miles Core Statistics
        if [[ "int" == "prd" ]]; then
            URL="athlon-miles-core.esp.corpintra.net:10040/miles/MilesAdmin?operation=Statistics"
        else
            URL="athlon-miles-core-int.esp.corpintra.net:10040/miles/MilesAdmin?operation=Statistics"
        fi
        print_log_message "START Miles Core Statistics"
        curl -sS "${URL}"
        print_log_message "END Miles Core Statistics"
        print_log_message "back up log files"
        dirname=/data/se/logs/web/logs_$(date +%Y-%m-%d_%H.%M.%S)
        run_as_jboss_user mkdir "${dirname}"
        find /data/se/logs/web -maxdepth 1 -type f -mmin -10 -exec cp -p -t "${dirname}" {} \;
        chmod 755 -R "${dirname}"
        print_log_message "${dirname}"
        ls -lrt "${dirname}"
        print_log_message "Calling Restart Script"
        ~/restart_country_se.sh
    fi
}

main 2>&1 | tee -a "${LOG_FILE}"
chmod 755 "${LOG_FILE}"
chown jboss-se:jboss "${LOG_FILE}"
