#!/bin/bash

################################################################################
# loading variables
DIR=$(dirname "${0}")
. "${DIR}"/../config/instance.env

################################################################################

# Functions
function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

compare_version() {

    # Meaning of the return values
    # 0: x = y
    # 1: x > y
    # 2: x < y

    # remove trailing . and .0"
    version1=$(sed -e 's/\([.][0]*\)*$//g' <<<${1})
    version2=$(sed -e 's/\([.][0]*\)*$//g' <<<${2})

    local IFS=.
    argument1=(${version1})
    argument2=(${version2})

    for ((i = 0; i < ${#argument1[@]}; i++)); do
        if [[ -z ${argument2[i]} ]] || ((${argument1[i]} > ${argument2[i]})); then
            returnvalue=1
            break
        fi
        if ((${argument1[i]} < ${argument2[i]})); then
            returnvalue=2
            break
        fi
    done

    # If no difference was found in the for loop do one addotional check
    if [[ "${returnvalue-default}" == "default" ]]; then
        # Even if argument2 is only longer because of ".0" we treat it as a higher number/version
        if ((${#argument1[@]} < ${#argument2[@]})); then
            returnvalue=2
        else
            returnvalue=0
        fi
    fi

    echo ${returnvalue}
}

function jboss_upgrade_preparation() {
    jboss_base_dir="${1}"
    print_log_message DEBUG "jboss_base_dir: ${jboss_base_dir}"

    if [ -d "${jboss_base_dir}" ]; then
        current_jboss_version=$(sed -r 's|.*([0-9]+[.][0-9]+[.][0-9]+).*|\1|g' "${jboss_base_dir}/version.txt")
        print_log_message INFO "current_jboss_version: ${current_jboss_version}"

        comparison_result=$(compare_version "${bin_jboss_version}" "${current_jboss_version}")

        if [[ ${comparison_result} -eq 1 ]]; then
            print_log_message INFO "Configured version higher than currently installed version"
            dir_backup_name="${jboss_base_dir}"_"${current_jboss_version}"_"${now}"
            mv "${jboss_base_dir}" "${dir_backup_name}"
            print_log_message INFO "Folder Renamed '${jboss_base_dir}' into '${dir_backup_name}'"
        fi
    else
        print_log_message INFO "'${jboss_base_dir}' doesn't exist, initial deployment will be done"
    fi
}

################################################################################

server_role="$1"
now=$(date '+%Y-%m-%d_%H.%M.%S')
print_log_message DEBUG "server_role: ${server_role}"
print_log_message INFO "bin_jboss_version: ${bin_jboss_version}"

################################################################################

if [[ "${country}" != "" && "${bin_jboss_version}" != ""  ]]; then
    # checking server type: -a = application server -w = web server
    if [[ "${server_role}" == "-a" ]]; then
        jboss_upgrade_preparation "${jboss_home_core}"
        jboss_upgrade_preparation "${jboss_home_ria}"
    elif [[ "${server_role}" == "-w" ]]; then
        jboss_upgrade_preparation "${jboss_home_web}"
    fi # server role
fi # act relevent variables supplied
