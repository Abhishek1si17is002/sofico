#!/bin/bash

while read -r dir; do
    if [[ -d "${dir}" ]]; then
        echo "Dir exists"
    else
        echo "Dir ${dir} does not exist"
    fi  
done < dirs
