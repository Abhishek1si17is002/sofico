#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env


#copy the operational scripts to jboss home
#cp ../op_scripts/* ~
#chmod +x ~

if [ "$1" == "-a" ]
then
    #core
    cp "${core_module_xml}" "${jdbc_home}"
    cp "${core_standalone_full_xml}" "${jboss_core_standalone_home}"
    
    #chmod +x ${core_start}
    #chmod +x ${core_stop}

    cp "${core_start}" "${jboss_core_bin_home}"
    cp "${core_start_post}" "${jboss_core_bin_home}"
    cp "${core_stop}" "${jboss_core_bin_home}"

    #ria
    cp "${ria_standalone_full_xml}" "${jboss_ria_standalone_home}"
    cp "${ria_passphrase_full}" "${jboss_ria_standalone_home}"

    #chmod +x "${ria_start}"
    #chmod +x "${ria_stop}"

    cp "${ria_start}" "${jboss_ria_bin_home}"
    cp "${ria_stop}" "${jboss_ria_bin_home}"
fi

if [ "$1" == "-w" ]
then
    cp "${web_standalone_full_xml}" "${jboss_web_standalone_home}"

    #chmod +x ${web_start}
    #chmod +x ${web_stop}

    cp "${web_start}" "${jboss_web_bin_home}"
    cp "${web_stop}" "${jboss_web_bin_home}"
fi
