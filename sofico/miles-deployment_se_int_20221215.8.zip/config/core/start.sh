#!/bin/bash

# default setting for Java parameter MaxMetaspaceSize
max_metaspace_size="-XX:MaxMetaspaceSize=512M"

# disable this parameter for Italy and UK Production
if ( [ "se" == "it" ] || [ "se" == "uk" ] ) && [ "int" == "prd" ]; then
    max_metaspace_size=""
fi

export JAVA_OPTS="-Xms4608M -Xmx4608M -Xloggc:/data/se/logs/core/gc.`date +%Y-%m-%d_%H.%M.%S`.log ${max_metaspace_size} -Xrs -Dmilesroot=/data/se/milesroot -Djboss.node.name=miles_core_se -Djboss.server.log.dir=/data/se/logs/core/"
RUNNING=$(ps -ef | grep /app/miles-se | grep miles_core_se | grep -v miles_ria_se | grep -v miles_web_se | grep -v grep | grep -v $0 | wc -l)
if [ ${RUNNING} -gt 1 ]; then
    echo miles_core_se still running ! Rerun stop script first !
else
    nohup /app/miles-se/bin/standalone.sh -c standalone-full.xml -b 0.0.0.0 -bmanagement=0.0.0.0 -Djava.net.preferIPv4Stack=true -Dfile.encoding=UTF-8 -Dclient.encoding.override=UTF-8 -Dorg.apache.catalina.connector.URI_ENCODING=UTF-8 -Dorg.apache.catalina.connector.USE_BODY_ENCODING_FOR_QUERY_STRING=true -Dsun.jnu.encoding=UTF-8 -Djboss.socket.binding.port-offset=0 >/data/se/logs/core/start.log 2>/data/se/logs/core/start.log &
fi
