echo 'check if jboss was stopped'
ps -aef | grep /app/milesweb-pt | grep -v grep | grep -v $0 | awk '{print $2}' > /app/milesweb-pt/bin/stop.check

for i in `cat /app/milesweb-pt/bin/stop.check`
do
    echo "kill process"
    kill -9 $i
done
sleep 5
echo 'clean temp files'
rm -rf /app/milesweb-pt/standalone/tmp/*
rm -f /app/milesweb-pt/bin/stop.check

