#!/bin/bash

systemctl start miles-se.service
systemctl start milesria-se.service

if [ -f "/data/se/athlon/jboss-se.crontab" ]; then
    su - jboss-se -c "crontab < /data/se/athlon/jboss-se.crontab"
fi
ps -aux | grep "jboss-se"

files_to_check="/app/miles-se/standalone/deployments/miles.ear /app/milesria-se/standalone/deployments/milesria.ear"

# no <"> arround ${files_to_check} because the content should be passed as multiple arguments
/home/jboss-se/check_jboss_startup.sh ${files_to_check}
