#!/bin/bash

DATE=`date +%Y-%m-%d`
LOG_FILE=/data/pt/logs/ria/site_check_${DATE}.log

DATE=`date +%Y-%m-%d_%H.%M.%S`
if curl -s --head  --request GET localhost:10021/milesria/ --max-time 10| grep "200 OK" > /dev/null; then
   echo "${DATE}:milesria is UP" |& tee -a ${LOG_FILE}
else
   echo "${DATE}:milesria is DOWN restarting mileria" |& tee -a ${LOG_FILE}
   systemctl restart milesria-pt.service
fi