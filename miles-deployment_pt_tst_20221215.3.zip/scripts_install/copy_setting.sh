#!/bin/bash

# copy the security settings from the settings file to files

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

echo "copy the settings file"

mkdir -p "${deployment_settings_home}"

if [ ! -f "${deployment_settings_home}"/setting-"${country}" ]; then
    cp "${deployment_home}"/"${country}"/config/settings "${deployment_settings_home}"/setting-"${country}"
fi
