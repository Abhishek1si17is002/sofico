#!/bin/bash

switch_user=${1}
script_description=${2}
script_name=${3}
other_arguments=${@:4}

(
    date +%Y-%m-%d_%H.%M.%S
    echo "start ${script_description}"

    # using sub shells for the script calls to allow those scripts to use 'exit 0' without terminate the whole script
    # don't quote ${other_arguments}; we want word splitting
    if [ "${switch_user}" == "true" ]; then
        ( su "${user}" "${script_name}" ${other_arguments} )
        exitcode=$?
    else
        ( source "${script_name}" ${other_arguments} )
        exitcode=$?
    fi

    echo "finished ${script_description}"

    # throwing the exit code to be available after this sub shell
    exit  ${exitcode}

) |& tee -a "${LOG_FILE}" && echo

exitcode=$?

if [ ${exitcode} -ne 0 ]; then
    echo "exitcode: ${exitcode}"
    # false is triggering an error for the trap. using 'exit' here instead would terminate the main script
    false
fi
