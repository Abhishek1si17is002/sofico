#!/bin/bash


#not all environments have a cron. So only copoy if exists.

if [ -f /data/se/athlon/jboss-se.crontab ]; then
    crontab < /data/se/athlon/jboss-se.crontab
fi

