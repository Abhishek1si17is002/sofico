echo 'check if jboss was stopped'
ps -aef | grep /app/miles-pt | grep -v grep | grep -v miles_ria_pt | grep -v miles_web_pt | grep -v $0 | awk '{print $2}' > /app/miles-pt/bin/stop.check

for i in `cat /app/miles-pt/bin/stop.check`
do
    echo "kill process"
    kill -9 $i
done
sleep 5
echo 'clean temp files'
rm -rf /app/miles-pt/standalone/tmp/*
rm -rf /app/miles-pt/standalone/data/*
rm -f /app/miles-pt/bin/stop.check