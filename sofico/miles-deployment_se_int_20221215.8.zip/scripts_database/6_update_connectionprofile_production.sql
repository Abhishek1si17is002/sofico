UPDATE connectionprofile
   SET name = 'se_acc',
       syskeyrange_id = 3,
       isenabled = 1
 WHERE connectionprofile_id = 1;

COMMIT;