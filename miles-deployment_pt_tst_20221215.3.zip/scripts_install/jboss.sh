#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

function install_jboss {
    izpack_config="$1"
    java -jar "${bin_jboss}" "${izpack_config}"
    exitcode=$?
    if [ "${exitcode}" -gt 0 ]; then
        echo "DEBUG exitcode: ${exitcode}"
        exit "${exitcode}"
    fi
}

if [ "$1" == "-a" ]
then
    echo "INFO JBoss installation for Miles Core"
    install_jboss "${jboss_config_core}"

    echo "INFO JBoss installation for Miles RIA"
    install_jboss "${jboss_config_ria}"
fi

if [ "$1" == "-w" ]
then
    install_jboss "${jboss_config_web}"
fi
