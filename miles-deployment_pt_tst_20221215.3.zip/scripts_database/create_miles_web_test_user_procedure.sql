create or replace PROCEDURE CreateWebUser(v_useraccount_id IN NUMBER, 
                                          v_signonid IN VARCHAR, 
                                          v_email IN VARCHAR, 
                                          v_contactrole_id1 IN NUMBER,
                                          v_contactrole_id2 IN NUMBER,
                                          v_contactrole_id3 IN NUMBER,
                                          v_contactrole_id4 IN NUMBER) 
IS
BEGIN

update useraccount 
   set signonid = v_signonid,
       email = v_email,
       password = 'XXXtest_user_passwordYYY'
 where useraccount_ID = v_useraccount_id;

delete 
  from contactcontactrole 
 where contact_ID = (select c.contact_id from contact c where c.useraccount_id = v_useraccount_id);  

insert into contactcontactrole (Contactrole_ID,Contact_ID) 
select v_contactrole_id1, c.contact_id
  from contact c 
where c.useraccount_id = v_useraccount_id;

insert into contactcontactrole (Contactrole_ID,Contact_ID) 
select v_contactrole_id2, c.contact_id
  from contact c 
where c.useraccount_id = v_useraccount_id;

insert into contactcontactrole (Contactrole_ID,Contact_ID) 
select v_contactrole_id3, c.contact_id
  from contact c 
where c.useraccount_id = v_useraccount_id;

insert into contactcontactrole (Contactrole_ID,Contact_ID) 
select v_contactrole_id4, c.contact_id
  from contact c 
where c.useraccount_id = v_useraccount_id;

update passwordrule 
   set applyrules = 0,
       passwordexpired = 0 
 where passwordrule_ID = (select ua.passwordrule_id from useraccount ua where ua.useraccount_id = v_useraccount_id);  
COMMIT;

END CreateWebUser;
/
