#!/bin/bash

# Remark regarding the log messages.
# logging can be seen if the script is called directory like "/app/milesweb-pt/bin/start.sh"
# if started as service via "~/start_country_pt.sh" (calling "systemctl start milesweb-pt.service")
# the logs can be checked via "journalctl -e -u milesweb-pt.service"
# This can be improved in the future by e.g. improving the service setup or sending the output directory to a log file

# Functions
function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

### Threshold of File created date to scan and delete
file_age_check=90
print_log_message INFO "Starting scanning and deleting files older than ${file_age_check} days"
original_ifs=${IFS}
IFS=$'\n'
for FILE in `find /data/se/logs/web -name "*.log*" -mtime +${file_age_check} -type f \
-not -name gc.log.0.current \
-not -name backup.log.current \
-not -name '*[a-z].log' \
| sort`;
do
    rm -fv ${FILE}
done

# The updated IFS value breaks the check of the 'validate' variable further below, therefore we set back the old value
IFS=${original_ifs}

print_log_message INFO "check if Miles backoffice/backend/core is available"

# how often should it be checked / number of seconds the loop is set to sleep
check_every=5
# how long should it be checked / how many seconds it check should be running
check_for=120
# how many checks will be made
checks=$(expr ${check_for} / ${check_every})

for i in $( seq 1 ${checks} )
do
    print_log_message DEBUG "Try ${i}"

    base_url=http://athlon-miles-core-tst.esp.corpintra.net:10040/miles/
    status="$(curl -Is ${base_url}servlet/be.sofico.basecamp.servlet.admin.Admin?operation=getVersionInfo | head -1)"
    validate=( $status )

    print_log_message DEBUG "base_url: ${base_url}"
    print_log_message DEBUG "status: ${status}"

    if [[ ! -z "${validate}" ]] && [ ${validate[-2]} == "200" ]; then
        print_log_message INFO "Miles core: reachable"

        process_check_command="ps -ef | grep /app/milesweb-se | grep -w miles_web_se | grep -v grep | grep -v  $0"
        running=$(eval "${process_check_command}" | wc -l)
        print_log_message DEBUG "running: ${running}"

        if [ ${running} -eq 0 ]; then
            # running = 0 start it
            export JAVA_OPTS="-Xms2048M -Xmx2048M -Xloggc:/data/se/logs/web/gc.`date +%Y-%m-%d_%H.%M.%S`.log -XX:MaxMetaspaceSize=512M -Xrs -Dmilesriaroot=/data/se/milesweb -Djboss.node.name=miles_web_se  -Djboss.server.log.dir=/data/se/logs/web/"
            nohup /app/milesweb-se/bin/standalone.sh -c standalone-full.xml -b 0.0.0.0  >/data/se/logs/web/miles.log 2>/data/se/logs/web/miles.log &
            # make sure this is running as the right user, either check user executing this or switch user...:?!
            print_log_message INFO "miles_web_se started"
            exit 0
        elif [ ${running} -eq 1 ]; then
            # running = 1 still running
            print_log_message WARN "miles_web_se still running ! Rerun stop script first !"
            exit 1
        else
            # running > 1 strange
            print_log_message ERROR "Too many processes are running, please investigate!"
            print_log_message ERROR "$(eval "${process_check_command}")"
            exit 1
        fi
        # status check of MilesWeb itself after the start
    else
        print_log_message ERROR "Miles core: not responding"
    fi

    sleep ${check_every}
done

print_log_message ERROR "Miles core was not reachable after trying for ${check_for} seconds."