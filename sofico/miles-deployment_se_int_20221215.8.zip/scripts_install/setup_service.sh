#!/bin/bash

#this script must be executed as root!

# create env xml file
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

if [ "$1" == "-a" ]
then
    #copy core
    cp "${core_service}" "${service_home}"/"${core_service_name}"

    #copy RIA
    cp "${ria_service}" "${service_home}"/"${ria_service_name}"

    #enable service core
    systemctl enable "${core_service_name}"

    #enable service RIA
    systemctl enable "${ria_service_name}"
fi

if [ "$1" == "-w" ]
then
    #web
    cp "${web_service}" "${service_home}"/"${web_service_name}"

    #enable service web
    systemctl enable "${web_service_name}"
fi

systemctl daemon-reload
