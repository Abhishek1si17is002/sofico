#!/bin/bash

# 1 activate debug logs, 0 deactivate debug logs
debug=0

function print_log_message() {
    if [ "DEBUG" == "${1}" ]; then
        if [ 1 -eq ${debug} ]; then
            echo -e "$(date '+%F %T')\t$1\t$2"
        fi
    else
        echo -e "$(date '+%F %T')\t$1\t$2"
    fi
}

# put arguments what to check (e.g. broker-mri.war broker.war fleet.war for web) in an array
# the arguments have to include the path to the files e.g. "/app/milesweb-prep/standalone/deployments"
files_to_check=("${@}")

print_log_message INFO "Watching the deployment of the .war/.ear files within JBoss."
print_log_message INFO "files_to_check: ${files_to_check[*]}"

# wait for 10 seconds to prevent that the old .deployed file is there before the actual new deployment starts
sleep 10

# define for how long the script should check the status of the deployment
# how often should it be checked / number of seconds the loop is set to sleep
check_every=5
# how long should it be checked / how many seconds should it be running
check_for=120
# how many checks will be made
checks=$(expr ${check_for} / ${check_every})

for i in $( seq 1 "${checks}" ); do

    # the array will be rebuild, to avoid gaps in between the indexes
    for index in "${!files_to_check[@]}"; do
        print_log_message DEBUG "index: ${index} files_to_check[${index}]: ${files_to_check[${index}]}"
        new_array+=( "${files_to_check[index]}" )
    done
    files_to_check=("${new_array[@]}")
    unset new_array

    print_log_message DEBUG "Check: ${i} | #files_to_check[@]: ${#files_to_check[@]} | files_to_check[*]: ${files_to_check[*]}"

    for deployment_file_index in ${!files_to_check[@]}; do

        deployment_file=${files_to_check[${deployment_file_index}]}
        print_log_message DEBUG "deployment_file_index: ${deployment_file_index} | deployment_file: ${deployment_file}"

        # .deployed = positive feedback, remove from the list of files to check
        if [ -f "${deployment_file}".deployed ]; then
            print_log_message INFO "Found ${deployment_file}.deployed. Removing it from 'files_to_check'."
            unset 'files_to_check[deployment_file_index]'
            continue
        fi

        # .failed = negative feedback, exit the whole script
        if [ -f "${deployment_file}".failed ]; then
            print_log_message ERROR "Found ${deployment_file}.failed. Please investigate why the deployement failed!"
            print_log_message ERROR "Checking the deployments aborted, fix this issue and then restart JBoss."
            exit
        fi

        # for example .isdeploying = continue loop
        print_log_message INFO "Status files for '${deployment_file}.<status>'"
        ls -l "${deployment_file}".*
    done

    # no more files in the list of files to check = end the loop
    if [ 0 -eq ${#files_to_check[@]} ]; then
        print_log_message INFO "Everything was sucessfully deployed within the treshold of ${check_for} seconds."
        exit
    fi

    sleep ${check_every}
done

print_log_message WARNING "For the following files the deployment wasn't done in the treshold of ${check_for} seconds."
for index in "${!files_to_check[@]}"; do
    print_log_message WARNING "- ${files_to_check[${index}]}"
done
print_log_message WARNING "Please check those deployments manually!"
