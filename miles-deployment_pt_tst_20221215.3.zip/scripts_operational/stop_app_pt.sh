#!/bin/bash

crontab -u jboss-pt -r

systemctl stop milesria-pt.service
systemctl stop miles-pt.service

ps -aux | grep "jboss-pt"