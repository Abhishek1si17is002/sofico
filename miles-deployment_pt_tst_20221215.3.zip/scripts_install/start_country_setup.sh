#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

# args
# 1st sofico file

# this script must be executed as root!

# sets a flag ("-a" or "-w") hard coded depending on server name
source sub/server_role.sh

su "${user}" init_country.sh "${server_role}"

su "${user}" deploy_sofico_release.sh "$1" 

source init_country_user.sh "${server_role}"
