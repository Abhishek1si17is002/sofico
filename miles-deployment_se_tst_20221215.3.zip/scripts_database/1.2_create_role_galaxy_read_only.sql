/* ************************* Create roles */

SET SERVEROUTPUT ON
DECLARE 
  dbs_role_count number;
BEGIN
  select count(*) into dbs_role_count from dba_roles where role = 'GALAXY_READ_ONLY';
    IF ( dbs_role_count = 0 ) THEN
        dbms_output.put_line('Role does not exists - creating role' );
        EXECUTE IMMEDIATE 'CREATE ROLE GALAXY_READ_ONLY NOT IDENTIFIED';
    ELSE
       dbms_output.put_line('Role exists' );
    END IF;
END;
/