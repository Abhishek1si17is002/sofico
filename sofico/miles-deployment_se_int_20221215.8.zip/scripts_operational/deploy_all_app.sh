#!/bin/bash

#1 arg
#<sofico file>

isdirectory() {
  if [ -d "$1" ]
  then
    #echo folder "$1" exists
    return 0 
  else
    #echo folder "$1" does not exist
    return 1
  fi
}


if [ "$2" == "2018.2" ]
then
    declare -a arr=("se" "es" "it" "pt")
fi

if [ "$2" == "2019.1" ]
then
    declare -a arr=("uk" "prep")
fi


## now loop through the above array
for i in "${arr[@]}"
do
   echo "$i"

    if isdirectory /data/deployment/"$i"; 
    then 
        echo present; 
        ~/stop_country_"$i".sh
        cd /data/deployment/"${i}"/scripts_install/ || { echo "cd /data/deployment/${i}/scripts_install/ failed"; exit; }
        chmod +x *.sh
        ./deploy_country.sh "${1}" -a
        ~/start_country_"$i".sh  
    fi

   # or do whatever with individual element of the array
done



