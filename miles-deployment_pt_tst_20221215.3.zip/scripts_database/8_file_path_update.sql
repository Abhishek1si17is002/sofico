UPDATE document
SET dirpath = REPLACE(
        dirpath,
        '/data/milesprd/athlonmiles-pt/documents/JasperReports/Out/',
        '/data/pt/documents/generated/'
    )
WHERE dirpath LIKE '/data/milesprd/athlonmiles-pt/documents/JasperReports/Out/%';

COMMIT;
