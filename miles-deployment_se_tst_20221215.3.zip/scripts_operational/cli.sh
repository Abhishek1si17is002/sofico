#!/bin/bash
#arg 1 ria|core
#arg 2 country
#arg 3 command
if [ "$1" == "-h" ]; then
  echo "Usage: $(basename "$0") ria|core country 'command'"
  exit 0
fi

if [ "$1" -eq "ria" ]; then

    path="/app/milesria-$2/bin/"

    case "$2" in
        "es") port="11011" ;;
        "pt") port="11021" ;;
        "it") port="11031" ;;
        "se") port="11041" ;;
        "uk") port="11051" ;;
        *) echo "unknown country"
        ;;
    esac
else

    path="/app/miles-$2/bin/"

    case "$2" in
        "es") port="11010" ;;
        "pt") port="11020" ;;
        "it") port="11030" ;;
        "se") port="11040" ;;
        "uk") port="11050" ;;
        *) echo "unknown country"
        ;;
    esac
fi

"${path}"jboss-cli.sh --connect --controller=localhost:"${port}" --command="$3"
