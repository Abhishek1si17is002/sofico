#!/bin/bash

# copy the security settings from the settings file to files

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

echo updating core standalone
echo  "${core_standalone_full_xml}"
source inject_setting.sh "${core_standalone_full_xml}" "${deployment_settings_home}"/setting-"${country}" -v

echo updating ria standalone
echo "${ria_standalone_full_xml}"
source inject_setting.sh "${ria_standalone_full_xml}" "${deployment_settings_home}"/setting-"${country}" -v

echo 2.2_create_galaxy_users.sql
source inject_setting.sh "${DIR}"/../scripts_database/2.2_create_galaxy_users.sql "${deployment_settings_home}"/setting-"${country}" -v

echo updating 7_create_cardata_user.sql
source inject_setting.sh "${DIR}"/../scripts_database/7_create_cardata_user.sql "${deployment_settings_home}"/setting-"${country}" -v

echo updating ejb
echo add_jboss_application_user.sh
source inject_setting.sh add_jboss_application_user.sh "${deployment_settings_home}"/setting-"${country}" -v

echo instance.
echo "${DIR}"/../config/instance.env
source inject_setting.sh "${DIR}"/../config/instance.env "${deployment_settings_home}"/setting-"${country}" -v

echo updating core boot properties
echo "${core_boot_properties}"
source inject_setting.sh "${core_boot_properties}" "${deployment_settings_home}"/setting-"${country}" -v

echo updating ame_documents.xml file
echo "${config_home_xml}"/ame_documents.xml
source inject_setting.sh "${config_home_xml}"/ame_documents.xml "${deployment_settings_home}"/setting-"${country}" -v

echo updating passphrase
echo "${DIR}"/../config/ria/passphrase.sh
source inject_setting.sh "${DIR}"/../config/ria/passphrase.sh "${deployment_settings_home}"/setting-"${country}" -v

echo updating create_miles_web_test_user_procedure.sql file
source inject_setting.sh "${DIR}"/../scripts_database/create_miles_web_test_user_procedure.sql "${deployment_settings_home}"/setting-"${country}" -v
