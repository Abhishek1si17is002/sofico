#!/bin/bash

# default setting for Java parameter MaxMetaspaceSize
max_metaspace_size="-XX:MaxMetaspaceSize=512M"

# disable this parameter for Italy and UK Production
if ( [ "pt" == "it" ] || [ "pt" == "uk" ] ) && [ "tst" == "prd" ]; then
    max_metaspace_size=""
fi

export JAVA_OPTS="-Xms2048M -Xmx2048M -Xloggc:/data/pt/logs/core/gc.`date +%Y-%m-%d_%H.%M.%S`.log ${max_metaspace_size} -Xrs -Dmilesroot=/data/pt/milesroot -Djboss.node.name=miles_core_pt -Djboss.server.log.dir=/data/pt/logs/core/"
RUNNING=$(ps -ef | grep /app/miles-pt | grep miles_core_pt | grep -v miles_ria_pt | grep -v miles_web_pt | grep -v grep | grep -v $0 | wc -l)
if [ ${RUNNING} -gt 1 ]; then
    echo miles_core_pt still running ! Rerun stop script first !
else
    nohup /app/miles-pt/bin/standalone.sh -c standalone-full.xml -b 0.0.0.0 -bmanagement=0.0.0.0 -Djava.net.preferIPv4Stack=true -Dfile.encoding=UTF-8 -Dclient.encoding.override=UTF-8 -Dorg.apache.catalina.connector.URI_ENCODING=UTF-8 -Dorg.apache.catalina.connector.USE_BODY_ENCODING_FOR_QUERY_STRING=true -Dsun.jnu.encoding=UTF-8 -Djboss.socket.binding.port-offset=0 >/data/pt/logs/core/start.log 2>/data/pt/logs/core/start.log &
fi
