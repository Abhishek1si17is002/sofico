/* ************************* Spool grant statements */

SET head OFF pagesize 5000 linesize 200
SET verify OFF
SET feedback OFF

spool /data/deployment/se/tmp/MILES_READ_ONLY_spooled.sql

SELECT
    'GRANT ' ||
    CASE
        WHEN object_type IN ('VIEW', 'TABLE') THEN 'SELECT '
        WHEN object_type = 'FUNCTION' THEN 'EXECUTE '
    END
    || 'ON '
    || UPPER('MILES')
    ||'.'
    || object_name
    || ' TO MILES_READ_ONLY;'
FROM 
    dba_objects
WHERE 
        owner = UPPER('MILES')
    AND object_type IN ('TABLE', 'FUNCTION')
ORDER BY
    object_type,
    object_name;

spool OFF

/* ************************* Execute spooled file */

@/data/deployment/se/tmp/MILES_READ_ONLY_spooled.sql
