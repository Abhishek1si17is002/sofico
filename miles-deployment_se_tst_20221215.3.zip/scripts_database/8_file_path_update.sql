UPDATE document
SET dirpath = REPLACE(
        dirpath,
        '/data/milesprd/athlonmiles-se/documents/JasperReports/Out/',
        '/data/se/documents/generated/'
    )
WHERE dirpath LIKE '/data/milesprd/athlonmiles-se/documents/JasperReports/Out/%';

COMMIT;
