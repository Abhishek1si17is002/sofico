-- should already be create through import

/* ************************* Assign roles */

GRANT CONNECT TO MILES;
GRANT IMP_FULL_DATABASE TO MILES;
GRANT RESOURCE TO MILES;
GRANT MILES_JATO TO MILES;

ALTER USER MILES DEFAULT ROLE ALL; 

/* ************************* Grant privilege */

GRANT UNLIMITED TABLESPACE TO MILES;