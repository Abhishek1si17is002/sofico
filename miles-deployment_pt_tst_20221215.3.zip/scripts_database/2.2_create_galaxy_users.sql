/* ************************* Variables */
@variables.sql

/* ************************* Create users */

CREATE USER GALAXY_OWNER
    IDENTIFIED BY "XXXgalaxy_owner_db_passwordYYY"
    PROFILE C##DAI_TECHUSER
    ACCOUNT LOCK
    DEFAULT TABLESPACE DATA
    TEMPORARY TABLESPACE TEMP;

CREATE USER GALAXY
    IDENTIFIED BY "XXXgalaxy_db_passwordYYY"
    PROFILE C##DAI_TECHUSER
    ACCOUNT UNLOCK
    DEFAULT TABLESPACE "USERS";

/* ************************* Assign roles */

GRANT MILES_READ_ONLY TO GALAXY_OWNER;
ALTER USER GALAXY_OWNER DEFAULT ROLE ALL; 

GRANT GALAXY_READ_ONLY TO GALAXY;
ALTER USER GALAXY DEFAULT ROLE ALL; 

/* ************************* Grant create session */

GRANT CREATE SESSION TO GALAXY;