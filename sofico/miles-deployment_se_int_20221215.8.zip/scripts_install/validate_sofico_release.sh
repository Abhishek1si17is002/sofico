#!/bin/bash

#this file checks if all required items are added to the sofico release.
VALID=true

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

rm result.txt
echo "the following files/directories are missing" > result.txt

isdirectory() {
  if [ -d "$1" ]
  then
    echo "folder $1 exists"
    return 0 
  else
    echo "folder $1 does not exist"
    echo "$1" >> result.txt
    return 1
  fi
}

isfile() {
  if [ -f "$1" ]
  then
    echo "file $1 exists"
    return 0 
  else
    echo "file $1 does not exist"
    echo "$1" >> result.txt
    return 1
  fi
}

#set variables
SOFICO_ZIP=$(basename "$1") ; echo "File to validate: ${SOFICO_ZIP}"
SOFICO_DIR=$(dirname "$1") ; echo "Sofico Folder ${SOFICO_DIR}"
rm -rf "${deploy_tmp_home}"/ACL
RELEASE=$(ls "$1" | awk -F - '{print $3}') ; echo Release to process: "${RELEASE}"
DELIVERY=$(ls "$1" | awk -F - '{print $4}')
DELIVERY=${DELIVERY%.*} ; echo Delivery to process: "${DELIVERY}"

#pre check
echo tmp folder is "${deploy_tmp_home}"
if  ! isdirectory "${deploy_tmp_home}"
then
  echo "cannot run validate"
  exit
fi

if  ! isfile "$1"
then
  echo "cannot run validate"
  exit
fi

#Action
unzip "$1" -d "${deploy_tmp_home}"
PATH_ROOT="${deploy_tmp_home}/ACL/MILES/${RELEASE}/BUILD/${DELIVERY}" ; echo root path is "${PATH_ROOT}"
#CHECK
if ! isdirectory "${PATH_ROOT}"; then VALID=false; fi
if ! isfile "${PATH_ROOT}"/manifest.txt; then VALID=false; fi 

BUILD=$(sed '3q;d' "${PATH_ROOT}"/manifest.txt | awk -F = '{print $2}') ; echo Build to process: "${BUILD}"
PATH_BATCH="${PATH_ROOT}"/batch
PATH_BATCH_WORKING="${PATH_BATCH}"/working
mkdir "${PATH_BATCH_WORKING}" ; echo "${PATH_BATCH_WORKING}" added

if ! isfile "${PATH_BATCH}"/MilesCLI_"${RELEASE}"_"${BUILD}"_jboss_linux.zip; then VALID=false; fi 
unzip "${PATH_BATCH}"/MilesCLI_"${RELEASE}"_"${BUILD}"_jboss_linux.zip -d "${PATH_BATCH_WORKING}"
if ! isfile "${PATH_BATCH_WORKING}"/jre/bin/java; then VALID=false; fi 
if ! isfile "${PATH_BATCH_WORKING}"/bin/MilesCLI.sh; then VALID=false; fi
if ! isdirectory "${PATH_BATCH_WORKING}"/properties/install; then VALID=false; fi

PATH_SERVER="${PATH_ROOT}"/server
PATH_SERVER_WORKING="${PATH_SERVER}"/working
mkdir "${PATH_SERVER_WORKING}" ; echo "${PATH_SERVER_WORKING}" added
if ! isfile "${PATH_SERVER}"/milesroot_ACL_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi
unzip "${PATH_SERVER}"/milesroot_ACL_"${RELEASE}"_"${BUILD}".zip -d "${PATH_SERVER_WORKING}"
if ! isfile "${PATH_SERVER}"/server_ACL_JBOSS_"${RELEASE}"_"${BUILD}".ear; then VALID=false; fi   
mkdir "${PATH_SERVER_WORKING}"/properties ; echo "${PATH_SERVER_WORKING}"/properties added
if ! isdirectory "${PATH_SERVER_WORKING}"/mmc/install; then VALID=false; fi
if ! isdirectory "${PATH_SERVER_WORKING}"/connectors/install; then VALID=false; fi
if ! isdirectory  "${PATH_SERVER_WORKING}"/documents/imagemap/install; then VALID=false; fi
if ! isfile "${PATH_SERVER_WORKING}"/milesweb/install/ProductConfig"${country_full}".xml; then VALID=false; fi

PATH_RIA="${PATH_ROOT}"/ria
PATH_RIA_WORKING="${PATH_RIA}"/working
mkdir "${PATH_RIA_WORKING}" ; echo "${PATH_RIA_WORKING}" added
if ! isfile "${PATH_RIA}"/milesriaroot_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi
if ! isfile "${PATH_RIA}"/milesria_"${RELEASE}"_"${BUILD}".ear; then VALID=false; fi

PATH_WEB="${PATH_ROOT}"/web
PATH_WEB_WORKING="${PATH_WEB}"/working
mkdir "${PATH_WEB_WORKING}" ; echo "${PATH_WEB_WORKING}" added
if ! isfile "${PATH_WEB}"/web_ACL_POS_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi
if ! isfile "${PATH_WEB}"/web_ACL_FLEET_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi
if ! isfile "${PATH_WEB}"/web_ACL_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi
unzip "${PATH_WEB}"/web_ACL_POS_"${RELEASE}"_"${BUILD}".zip -d "${PATH_WEB_WORKING}"
unzip "${PATH_WEB}"/web_ACL_FLEET_"${RELEASE}"_"${BUILD}".zip -d "${PATH_WEB_WORKING}"
unzip "${PATH_WEB}"/web_ACL_"${RELEASE}"_"${BUILD}".zip -d "${PATH_WEB_WORKING}"
if ! isdirectory "${PATH_WEB_WORKING}"/config_ACL_POS/; then VALID=false; fi
if ! isdirectory "${PATH_WEB_WORKING}"/config_ACL_FLEET/; then VALID=false; fi
if ! isdirectory "${PATH_WEB_WORKING}"/config_ACL/; then VALID=false; fi
if ! isfile "${PATH_WEB_WORKING}"/war/ACL_POS.war; then VALID=false; fi
if ! isfile "${PATH_WEB_WORKING}"/war/ACL_FLEET.war; then VALID=false; fi
if ! isfile "${PATH_WEB_WORKING}"/war/ACL.war; then VALID=false; fi

PATH_DATABASE="${PATH_ROOT}"/database
PATH_DATABASE_WORKING="${PATH_DATABASE}"/working
mkdir "${PATH_DATABASE_WORKING}" ; echo "${PATH_DATABASE_WORKING}" added
if ! isfile "${PATH_DATABASE}"/database_ACL_"${RELEASE}"_"${BUILD}".zip; then VALID=false; fi

rm -rf "${deploy_tmp_home}"/ACL
echo "${VALID}"
if "${VALID}" ; then
  echo "2wk patch is valid."
else
  echo "2wk patch is not valid."
  echo " please check result.txt for details"

  cat result.txt
fi
