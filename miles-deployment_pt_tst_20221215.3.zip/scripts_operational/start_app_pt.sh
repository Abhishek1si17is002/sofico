#!/bin/bash

systemctl start miles-pt.service
systemctl start milesria-pt.service

if [ -f "/data/pt/athlon/jboss-pt.crontab" ]; then
    su - jboss-pt -c "crontab < /data/pt/athlon/jboss-pt.crontab"
fi
ps -aux | grep "jboss-pt"

files_to_check="/app/miles-pt/standalone/deployments/miles.ear /app/milesria-pt/standalone/deployments/milesria.ear"

# no <"> arround ${files_to_check} because the content should be passed as multiple arguments
/home/jboss-pt/check_jboss_startup.sh ${files_to_check}
