echo 'check if jboss was stopped'
ps -aef | grep /app/milesweb-se | grep -v grep | grep -v $0 | awk '{print $2}' > /app/milesweb-se/bin/stop.check

for i in `cat /app/milesweb-se/bin/stop.check`
do
    echo "kill process"
    kill -9 $i
done
sleep 5
echo 'clean temp files'
rm -rf /app/milesweb-se/standalone/tmp/*
rm -f /app/milesweb-se/bin/stop.check

