export JAVA_OPTS="-Xms2048M -Xmx2048M -Xloggc:/data/se/logs/ria/gc.`date +%Y-%m-%d_%H.%M.%S`.log -XX:MaxMetaspaceSize=512M -Xrs -Dmilesriaroot=/data/se/milesriaroot -Djboss.node.name=miles_ria_se -Djboss.server.log.dir=/data/se/logs/ria/"
RUNNING=`ps -ef | grep /app/milesria-se | grep miles_ria_se | grep -v grep | grep -v  $0 | wc -l`
if [ "${RUNNING}" -gt 1 ]; then
    echo miles_ria_se still running ! Rerun stop script first !
else
    nohup /app/milesria-se/bin/standalone.sh -c standalone-full.xml -b 0.0.0.0 -bmanagement=0.0.0.0 -Djava.net.preferIPv4Stack=true -Dfile.encoding=UTF-8 -Dclient.encoding.override=UTF-8 -Dorg.apache.catalina.connector.URI_ENCODING=UTF-8 -Dorg.apache.catalina.connector.USE_BODY_ENCODING_FOR_QUERY_STRING=true -Dsun.jnu.encoding=UTF-8  -Djboss.socket.binding.port-offset=0 >/data/se/logs/ria/start.log 2>/data/se/logs/ria/start.log &
fi
