#!/bin/bash


#not all environments have a cron. So only copoy if exists.

if [ -f /data/pt/athlon/jboss-pt.crontab ]; then
    crontab < /data/pt/athlon/jboss-pt.crontab
fi

