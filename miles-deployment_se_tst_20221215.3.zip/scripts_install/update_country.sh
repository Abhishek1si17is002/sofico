#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

# sets a flag ("-a" or "-w") hard coded depending on server name
source sub/server_role.sh

echo "creating folder structure"
su "${user}" folder_structure.sh "${server_role}"
echo "finished creating folder structure"

echo "setting security"
source security.sh "${server_role}"
echo "finished setting security"

echo "distributing config files"
source distribute_config_files.sh "${server_role}"
echo "finished distributing config files"

if [ "${server_role}" == "-a" ]
then
    echo "deploying sofico release"
    source deploy_sofico_release.sh "$1"
    echo "finished deploying sofico release"
fi

if [ "${server_role}" == "-w" ]
then
    echo "deploying sofico release"
    source deploy_sofico_release.sh "$1" -w
    echo "finished deploying sofico release"
fi

exit 0

echo "setting ownership for country user"
source owner.sh "${server_role}"
echo "finished setting ownership for country user"

echo "setting permissions"
source permissions.sh
echo "finished setting permissions"
