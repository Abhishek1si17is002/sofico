#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

#usermod -aG wheel ${user}
#usermod -aG wheel ${country_user}

#if [ "$1" == "-a" ]
#then
    #chmod g+s /data/se/logs/cli
    #chmod g+s /data/es/logs/cli
    #chmod g+s /data/pt/logs/cli
    #chmod g+s /data/it/logs/cli
#fi

#CCM-829
#find /data -name \Ending_Contracts.xml -type f -exec rm -f {} \;
#find /data -name \Excess_Mileage_Contracts.xml -type f -exec rm -f {} \;

# consider to remove this in the future, the file should be gone on all environments. 
# if we want to add it on purpose in the future it will fail.
# added "-f" to avoid errors if the file does not exist
rm -f "${data_miles_home}"/milesweb/sql/Ending_Contracts.xml
rm -f "${data_miles_home}"/milesweb/sql/Excess_Mileage_Contracts.xml
