#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

run_script()
{
    echo "Starting script: " "$1"
    if [ "${1}" != "3_role_miles_read_only_permissions.sql" ] 
    then
        source exec_db_script.sh "$1"
    else
        source exec_db_script_silent.sh "$1"
    fi
    echo "Ending script: " "$1"
}

echo "Start of script..."
    run_script 1.1_create_role_miles_read_only.sql
    run_script 1.2_create_role_galaxy_read_only.sql
    
    if [ "${country}" != "uk" ]
    then
        run_script 1.3_create_role_jato.sql
    fi
    
    run_script 2.1_permissions_miles_user.sql
    run_script 2.2_create_galaxy_users.sql
    run_script 3_role_miles_read_only_permissions.sql
    run_script 4_create_trigger_login.sql
    run_script 5_create_mmc_connectionprofile.sql
    run_script 6_update_connectionprofile_production.sql
    run_script 7_create_cardata_user.sql
    run_script 8_file_path_update.sql

    if [ "${country}" == "se" ]
    then
        run_script 9.3_syskeyrange_update_se.sql
    fi
    if [ "${country}" == "es" ]
    then
        run_script 9.1_syskeyrange_update_es.sql
    fi
    if [ "${country}" == "pt" ]
    then
        run_script 9.4_syskeyrange_update_pt.sql
    fi
    if [ "${country}" == "it" ]
    then
        run_script 9.2_syskeyrange_update_it.sql
    fi
echo "End of script..."
