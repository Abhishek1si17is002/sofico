echo 'check if jboss was stopped'
ps -aef | grep /app/milesria-pt | grep -v grep | grep -v miles_web_pt | grep -v $0 | awk '{print $2}' > /bin/stop.check

for i in `cat /bin/stop.check`
do
    echo "kill process"
    kill -9 $i
done
sleep 5
echo 'clean temp files'
rm -rf /app/milesria-pt/standalone/tmp/*
rm -f /bin/stop.check
