#!/bin/bash

echo "creating country specific user"
source country_user.sh
echo "finished creating country specific user"

echo "copy the operational scripts to country user's home"
source op_scripts.sh  "$1"
echo "finished copying the operational scripts to country user's home"

echo "setting ownership for country user"
source owner.sh "$1"
echo "finished setting ownership for country user"

echo "setting permissions"
source permissions.sh
echo "finished setting permissions"