#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

install -d "${jdbc_home}"
cp "${bin_jdbc}" "${jdbc_home}"
