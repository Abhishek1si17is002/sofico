call createwebuser(601532, 'FLEET', 'ingo.von.ameln@athlon.com', 7, 8, 2, 1);
call createwebuser(601532, 'POS', 'ingo.von.ameln@athlon.com', 7, 8, 4, 16);
