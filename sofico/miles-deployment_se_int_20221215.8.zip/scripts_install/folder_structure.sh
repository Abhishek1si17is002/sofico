#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

mkdir -p "${jboss_home}"
mkdir -p "${data_home}"/"${instance}"
mkdir -p "${data_logs_home}"
mkdir -p "${data_logs_home}"/deployment
mkdir -p "${data_logs_home}"/deployment/ame
mkdir -p "${data_logs_home}"/deployment/ame/{documents,application}

if [ "$1" == "-a" ]
then
    mkdir -p "${jboss_home_core}"
    mkdir -p "${jboss_home_ria}"
    mkdir -p "${jboss_home_cli}"

    mkdir -p "${data_miles_home}"
    mkdir -p "${data_milesria_home}"
    mkdir -p "${data_document_home}"
    mkdir -p "${data_documents_imported_home}"
    mkdir -p "${data_transfer_invoice_home}"
    mkdir -p "${data_transfer_e_invoice_home}"
    mkdir -p "${data_export_search_data_aa_home}"
    mkdir -p "${data_export_search_data_finance_home}"
    mkdir -p "${data_export_search_data_i247_home}"
    mkdir -p "${data_export_search_data_insurance_home}"
    mkdir -p "${data_export_search_data_mrt_home}"
    mkdir -p "${data_export_search_data_operations_home}"
    mkdir -p "${data_export_search_data_reporting_home}"
    mkdir -p "${data_export_search_data_sales_home}"
    mkdir -p "${data_ACL_Remarketing_FleetVehicles_Export_local_home}"
    mkdir -p "${data_ACL_Remarketing_FleetVehicles_Export_remote_home}"

    mkdir -p "${data_athlon_home}"
    mkdir -p "${data_batch_home}"

    mkdir -p "${data_jasper_swap}"
    mkdir -p "${data_jasper_template}"

    mkdir -p "${log_core_home}"
    mkdir -p "${log_ria_home}"
    mkdir -p "${log_cli_home}"

    mkdir -p "${log_batch_home}"

    ln -s "${jboss_home_cli}"/bin "${data_batch_home}"/cli
    ln -snf "${data_documents_imported_home}"/ "${data_jasper_template}"/linktodocuments
fi

if [ "$1" == "-w" ]
then
    mkdir -p "${jboss_home_web}"
    mkdir -p "${data_milesweb_home}"
    mkdir -p "${log_web_home}"
    mkdir -p "${data_web_usersettings}"
    mkdir -p "${data_web_tmp}"

    mkdir -p "${web_carpic_download_home}"
    mkdir -p "${web_carpic_script_home}"
    mkdir -p "${web_carpic_image_home}"
fi
