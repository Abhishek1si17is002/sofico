#!/bin/bash



systemctl stop milesweb-pt.service

ps -aux | grep "jboss-pt"