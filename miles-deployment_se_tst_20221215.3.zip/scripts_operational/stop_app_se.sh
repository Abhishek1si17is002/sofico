#!/bin/bash

crontab -u jboss-se -r

systemctl stop milesria-se.service
systemctl stop miles-se.service

ps -aux | grep "jboss-se"