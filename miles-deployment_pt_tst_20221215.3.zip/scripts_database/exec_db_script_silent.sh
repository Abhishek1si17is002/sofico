#!/bin/bash

# create a sql plus connection in silent mode

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

sqlplus -s "${db_user}"/"${db_pass}"@"${db_connectionstring}" < "$1"
