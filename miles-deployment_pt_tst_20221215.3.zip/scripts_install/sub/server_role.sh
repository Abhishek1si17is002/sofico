#!/bin/bash

# This script will set based on the hostname a server role flag
# "-a" for application server
# "-w" for web server

# Logging with time stamp
function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

server_name=$(hostname -s)

# dfsealesp503
# dfsealesp505
# ifsealesp505
# sfsealesp505
if [[ "${server_name}" =~ [dis]fsealesp50[35] ]]; then
    export server_role="-a"
fi

# dfsealesp504
# ifsealxsp504
# sfsealxsp504
if [[ "${server_name}" =~ [dis]fseal[ex]sp504 ]]; then
    export server_role="-w"
fi

if [ "${server_role}" ]; then
    print_log_message "INFO" "server name '${server_name}' recognized, server role set to: ${server_role}"
else
    print_log_message "ERROR" "server name '${server_name}' not recognized, no server role flag set"
    exit 1
fi
