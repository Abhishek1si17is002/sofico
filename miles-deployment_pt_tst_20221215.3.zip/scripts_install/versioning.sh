#!/bin/bash

# populate below on verion.txt
# Part of the values are updated by Build, Deployment scripts
# deploy-time={variable-replaced by deploy_country.sh}
# git-commit={variable-replaced by create-config.bat}
# build-time={variable-replaced by create-config.bat}
# build-number={variable-replaced by CI pipeline} (in case of execution on developer machine add "local-build" as value)
# deployed-file={variable-replaced by deploy_country.sh} 

date_time_val=$(date '+%Y-%m-%d_%H.%M.%S')

#variable of the file path
file_path="$1"
#variable of the deployed file
deployed_file="$2"
#variable name of the deployed file to search for
var_name="deployed-file"

update_file (){
    filename="$1"
    searchtxt="$2"
    replacetxt="$3"

    if [[ "${searchtxt}" != "" && "${replacetxt}" != "" ]]; then
        sed -i "s|${searchtxt}|${replacetxt}|" "${filename}"
    fi
}

update_file "${file_path}" "#{deploy-time}#" "${date_time_val}"

#Check if there is a deployed_file parameter
if [ -z "${deployed_file}" ]; then
    echo "no deployed file variable available"
    exit 0
fi

#get the last deployed_file value
last_deployed_file=$(grep "${var_name}" "${file_path}")
#set the new deployed file value
new_deployed_file="${var_name}=${deployed_file}"
#update the value in the file
echo "execute update_file ${file_path} ${last_deployed_file} ${new_deployed_file}"
update_file "$file_path" "${last_deployed_file}" "${new_deployed_file}"
echo "deployed_file variable updated to $new_deployed_file"

exit 0
