#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

if [ "$1" == "-a" ]
then
    touch "${log_core_start}"
    touch "${log_core_stop}"
    touch "${log_ria_start}"
    touch "${log_ria_stop}"
fi

if [ "$1" == "-w" ]
then
    touch "${log_web_start}"
    touch "${log_web_stop}"
fi
