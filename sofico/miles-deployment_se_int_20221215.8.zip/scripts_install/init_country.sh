#!/bin/bash

DN="${PWD}"

echo "creating folder structure"
source folder_structure.sh "$1"
echo "finished creating folder structure"

echo "copy settings file"
source copy_setting.sh
echo "finished copy settings file"

echo "setting security"
source security.sh "$1"
echo "finished setting security"

echo "creating jboss instance"
source jboss.sh "$1"
echo "finished creating jboss instance"

if [ "$1" == "-a" ]
then
    echo "creating jdbc"
    source jdbc.sh
    echo "finished creating jdbc"
fi

echo "distributing config files"
source distribute_config_files.sh "$1"
echo "finished distributing config files"

echo "creating logfiles"
source logfiles.sh "$1"
echo "finished creating logfiles"

if [ "$1" == "-a" ]
then
    echo "creating ejb user"
    source add_jboss_application_user.sh
    echo "finished creating ejb user"

    echo "running database scripts for galaxy and jato"
    cd "${DN}" || { echo "cd ${DN} failed"; exit; }
	source run_db_scripts.sh
    cd "${DN}" || { echo "cd ${DN} failed"; exit; }
    echo "finished running database scripts for galaxy and jato"
fi
