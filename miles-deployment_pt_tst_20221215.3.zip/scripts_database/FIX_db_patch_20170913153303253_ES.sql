UPDATE syskeyrange SET low = 525000, high = 599999 WHERE syskeyrange_id = 2;
UPDATE syskeytable2 SET start_id = 525000 WHERE start_id != 525000;
UPDATE syskeytable2 SET last_id = 525000 WHERE last_id < 500000;
commit;
