#!/bin/bash

DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env

JATO_DIRECTORY="${data_miles_vehicle_home}"

DUMP_DIRECTORY="${JATO_DIRECTORY}/AWS_DUMPS"

PATTERN="pt-*-miles-*.@(dmp|log)"


function print_log_message() {
    echo -e "$(date '+%F %T')\t$1\t$2"
}

run_script()
{
    source "${DIR}"/exec_db_script.sh "$1"
}

cleanup_old_exports() {
    TARGET=${1}/${PATTERN}
    if compgen -G "${TARGET}" > /dev/null; then
        rm -fv ${1}/${PATTERN}
    else
        print_log_message INFO "No Old Dumps Found!"
    fi
}

move_exports() {
    TARGET=${1}/${PATTERN}
    if compgen -G "${TARGET}" > /dev/null; then
        mv -v ${1}/${PATTERN} ${DUMP_DIRECTORY}
    else
        print_log_message INFO "No New Dumps Found!"
    fi
}

shopt -s extglob
print_log_message "INFO" "Ensuring ${DUMP_DIRECTORY} exists"
mkdir -p "${DUMP_DIRECTORY}"
print_log_message "INFO" "Cleaning up Old Files"
cleanup_old_exports "${DUMP_DIRECTORY}"
print_log_message "INFO" "Starting Export..."
run_script "${DIR}/exportDB.sql"
print_log_message "INFO" "Export finished!"
print_log_message "INFO" "Moving Files to ${DUMP_DIRECTORY}"
move_exports "${JATO_DIRECTORY}"
print_log_message "INFO" "Listing contents of ${DUMP_DIRECTORY}"
ls -lrt "${DUMP_DIRECTORY}"
print_log_message "INFO" "Done"
shopt -u extglob
