#!/bin/bash

# source folder is: web_carpic_download_home
# target is: web_carpic_image_home

function files_folder_statistics() {
    echo "files in '/data/pt/miles_vehicle_data/images/jato/' ${1} extracting" >> "${LOG_FILE}"
    find /data/pt/miles_vehicle_data/images/jato/ -type f | wc -l >> "${LOG_FILE}"

    echo "folders in '/data/pt/miles_vehicle_data/images/jato/' ${1} extracting" >> "${LOG_FILE}"
    find /data/pt/miles_vehicle_data/images/jato/ -type d | wc -l >> "${LOG_FILE}"
}

LOG_FILE=/data/pt/logs/deployment/unzip_carimages_$(date +%Y-%m-%d_%H.%M.%S).log

echo "Start: $(date +%Y-%m-%d_%H.%M.%S)" >> "${LOG_FILE}"

files_folder_statistics "before"

unzip -o "/data/pt/miles_vehicle_data/downloads/*.zip" -d /data/pt/miles_vehicle_data/images/jato/ >> "${LOG_FILE}" 2>&1

files_folder_statistics "after"

echo "End: $(date +%Y-%m-%d_%H.%M.%S)" >> "${LOG_FILE}"
