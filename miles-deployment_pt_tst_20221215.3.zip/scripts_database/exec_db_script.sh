#!/bin/bash

# create a sql plus connection
 
DIR=$(dirname "$0")
. "${DIR}"/../config/instance.env


sqlplus "${db_user}"/"${db_pass}"@"${db_connectionstring}" < "$1"
