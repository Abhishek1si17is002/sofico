/* ************************* Variables */

define GALAXY_READ_ONLY_ROLE='GALAXY_READ_ONLY'
define GALAXY_OWNER_SCHEMA='GALAXY_OWNER'
define GALAXY_CONNECT_USER='GALAXY'
define GALAXY_OWNER_PASSWORD='XXXgalaxy_owner_db_passwordYYY'
define GALAXY_PASSWORD='XXXgalaxy_db_passwordYYY'
define JATO_PASSWORD='XXXjato_db_passwordYYY'

define MILES_READ_ONLY_ROLE='MILES_READ_ONLY'
define MILES_OWNER_SCHEMA='MILES'
define MILES_JATO_ROLE='MILES_JATO'